echo "------------------`ls /home/Storage_Plugins/Frontend/xucw/GP3/GPUcore/01.Documents/GP3/02.Tech/04.Design/01.Spec/SOC/lowpower/low_power_parameters* | tail -n 1`----------------------------"
/usr/bin/python3 ./gen_upf.py `ls /home/Storage_Plugins/Frontend/xucw/GP3/GPUcore/01.Documents/GP3/02.Tech/04.Design/01.Spec/SOC/lowpower/low_power_parameters* | tail -n 1`
