
__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  reg_table_parse.py - python code for parsing excel table.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''



#========================================
# UPF version declaration
#========================================
INDENT_SP = ' '*4

HEADER_STRING = '''\

# UPF DIRECTORY
#set UPF_DIR /home/Users/huangyh/Desktop/huangyh/workdir/G3_PRJ/SVN_G3_PRJ_202203/frontend/vc_static_check/upf

# USE UPF 2.1 
set_design_attributes -elements {.} -attribute enable_state_propagation_in_add_power_state true

'''

#========================================
# power domain block
#========================================
SUPPLY_SET_HEAD = '''\
##################################################################################
# SUPPLY SETS (EXPLICIT)
##################################################################################

'''

SUPPLY_SETS = '''\
 create_supply_set %s            
'''

POWER_DOMAIN_HEAD = '''\

##################################################################################
# POWER DOMAINS
###################################################################################
'''

POWERDOMAINS_INCLUDE_SCOPE = '''\

create_power_domain %s -supply {primary %s} -supply {default_isolation %s} -include_scope    

'''

POWERDOMAINS_NOC = '''\

create_power_domain %s -elements {%s} -supply {primary %s} -supply {default_isolation %s}  

'''

POWERDOMAINS_IP = '''\

create_power_domain %s -elements {%s} -supply {primary %s}    

'''


#========================================
# REFILE supply set
#========================================

REFILE_SUPPLY_SET_HEAD = '''\
#########################################
#refine supply-set
#########################################

'''

CONNECT_SUPPLY_PORT_AND_NET = '''\
create_supply_port %s
create_supply_net %s
connect_supply_net -ports %s %s

'''

CONNECT_SUPPLY_PORT_VSS = '''\
create_supply_port VSS
create_supply_net VSS
connect_supply_net -ports VSS VSS

'''

REFILE_SUPPLY_SET = '''\
create_supply_set %s -function {power %s} -update

'''

REFILE_SUPPLY_SET_VSS = '''\
create_supply_set %s -function {ground VSS} -update

'''

#========================================
# power state table
#========================================


POWER_STATE_TABLE_HEAD = '''\
#####################################################################################
# POWER STATE TABLE (UPF 2.1)
#####################################################################################


'''

ADD_POWER_STATE_ON = '''\
add_power_state  %s -state %s_ON {-supply_expr {power == {FULL_ON %s} }}

'''

ADD_POWER_STATE_OFF = '''\
add_power_state  %s -state %s_OFF {-supply_expr {power == {OFF}} -simstate CORRUPT}

'''

ADD_POWER_STATE_GROUND = '''\
add_power_state  SS_MAIN 	    -state GND              {-supply_expr {ground == {FULL_ON 0.0} }}

'''


CREATE_PST = '''\
create_pst %s -supplies {%sSS_MAIN.ground}

'''

ADD_PST_STATE = '''\
add_pst_state %s -pst %s -state {%s GND}

'''

#========================================
# isolation config table
#========================================

PORT_LIST_HEAD = '''
#####################################################################################################
#PORTS LIST
#####################################################################################################

'''
ISOLATION_CONFIG_HEAD = '''
#####################################################################################################
#ISOLATION  CONFIG
#####################################################################################################

'''
SET_DONT_ISO_PORT = '''
set_isolation ISO_PD_%s_DONT_ISO -domain PD_%s -source SS_%s -elements $%s -no_isolation

'''

SET_ISOLATION_CONFIG_HIGH = '''
set_isolation %s -domain %s -source %s -isolation_supply_set %s -clamp_value 1 -name_suffix %s \
    -elements $%s_ISO_HIGH_PORT 

'''
SET_ISOLATION_CONFIG_LOW = '''
set_isolation %s -domain %s -source %s -isolation_supply_set %s -clamp_value 0 -name_suffix %s \
    -exclude_elements $%s_ISO_HIGH_PORT -applies_to %s

'''




SET_ISOLATION_CONTROL = '''
set_isolation_control %s -domain %s -isolation_sense %s -isolation_signal %s -location %s

'''

LEVEL_SHIFT_CONFIG_HEAD = '''
###################################
#LEVEL-SHIFTER  CONFIG
###################################

'''

SET_LEVEL_SHIFT = '''
set_level_shifter %s -domain %s -source %s -applies_to %s -rule %s -location self \
-name_suffix %s -input_supply %s

'''


MAP_CELL_HEAD = '''
#############################
#       map_cell
#############################

'''

MAP_ISOLATION_CELL = '''
map_isolation_cell %s -domain %s -lib_cells {%s}

'''

MAP_LEVEL_SHIFT_CELL = '''
map_level_shifter_cell %s -domain %s -lib_cells {%s}
'''
