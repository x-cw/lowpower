## need change current_design
## input signal number
#set input_signal_num [sizeof_collection   [get_ports * -filter "pin_direction =~ in"]]
#echo "${curr_design} input signal num (A): $input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt
#
## echo floating_signals_list
#foreach_in_collection check_port [get_ports * -filter "port_direction =~ in"] {
#   set port_name [get_attribute [get_ports $check_port] full_name]
#   set count [sizeof_collection [all_fanout -flat -from [get_ports $port_name]]]
#   if {$count == 1} {
#        incr floating_signals_num
#        set floating_signals [get_attribute [get_ports $port_name] full_name]
#        echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
#   }
#}
#
## floating signlas number
#echo "${curr_design} is floating signlas num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
#
## should insert lp cell number
#set should_insert_lp_cell_num [expr $input_signal_num - $floating_signals_num]
#echo "${curr_design} should insert lp cells num (C=A-B): $should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt
#
##  inserted lp cell number
#set insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
#echo "${curr_design} is inserted lp cells num: $insert_lp_cell_num  \n\n\n\n" >> ../reports/insert_lp_cell_num_check.rpt

################################################################################################################################
current_design ${design_top}
echo "" > ../reports/insert_lp_cell_num_check.rpt


set top_should_insert_lp_cell_sum 0
set top_floating_signals_sum 0
set should_insert_lp_cell_sum 0
set floating_signals_sum 0
set insert_lp_cell_sum 0
set subtop_insert_lp_cell_sum 0
set subtop_insert_lp_cell_num 0
echo "" > ../reports/${design_top}_floating_signals_list.rpt

if { $sub_designs != ""} {
foreach sub_design $sub_designs {
    if {[get_designs $sub_design ] != ""} {
      set curr_design $sub_design
      set sub_input_cell [get_object_name  [get_cells * -filter "ref_name == $sub_design" -hierarchical] ]
      echo "" > ../reports/${curr_design}_floating_signals_list.rpt
      foreach sub_empty_design $sub_empty_designs {
        if {[get_designs $sub_empty_design ] != ""} {

          set sub_output_cell [get_cells * -filter "ref_name == $sub_empty_design" -hierarchical]
          set sub_input_cell_i "$sub_input_cell/*"


          if { ($design_top == "left_top") || ($design_top == "right_top") } {
               set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
               set input_net_signals [get_nets -of [get_pins -of $output_net_signals] -boundary_type upper]
               set input_signals [get_pins -of  $input_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]

               set sub_output_cell_t  [get_object_name $sub_output_cell]
               set sub_output_cell_i "$sub_output_cell_t/*"
               set sub_output_to_noc_pins [get_pins -of [get_nets -of [get_pins -of [get_nets -of $input_signals]] -boundary_type lower ] -filter "full_name =~ \"$sub_output_cell_i\"" ]
               set noc_check_pins [get_pins "$sub_output_cell_t/M* $sub_output_cell_t/*PULLUP_EN" -filter "pin_direction =~ out"]
               set sub_output_to_top_pins [remove_from_collection [remove_from_collection [get_pins $sub_output_cell_i -filter "pin_direction =~ out"] $sub_output_to_noc_pins] $noc_check_pins]


              # input signal number
              set sub_output_to_top_num [sizeof_collection  $sub_output_to_top_pins ]
              echo "$sub_empty_design output (to top) signals num (A): $sub_output_to_top_num" >> ../reports/insert_lp_cell_num_check.rpt

              set floating_signals_num 0
              
              # echo floating_signals_list
              foreach_in_collection check_pin $sub_output_to_top_pins {
                 set pin_name [get_attribute [get_pins $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
                 if {$count == 1} {
                      incr floating_signals_num
                      set floating_signals [get_attribute [get_pins $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${design_top}_floating_signals_list.rpt
                 }
              }

              # floating signlas number
              echo "$sub_empty_design output (to top) is floating signlas  num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
              
              # should insert lp cell number
              set should_insert_lp_cell_num [expr $sub_output_to_top_num - $floating_signals_num]
              echo "$sub_empty_design output (to top) should insert lp cells num  (C=A-B): $should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt



              # top is inserted  lp cell number
              set subtop_dir [file dirname [get_object_name $sub_output_cell]]
              set subtop_insert_lp_cell_num [sizeof_collection   [get_cells $subtop_dir/.* -regexp  -filter "ref_name =~ .*LVLU.* || ref_name =~ .*LVLD.* || ref_name =~ .*ISO.*" ]]
              echo "$subtop_dir is inserted lp cells num  : $subtop_insert_lp_cell_num\n"  >> ../reports/insert_lp_cell_num_check.rpt



          } else {


              # get sub_design pin signals to/from sub_empty_design 
              if { $design_top == "mid_top_wrap" } {
                set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
                set input_net_signals [get_nets -of [get_pins -of $output_net_signals] -boundary_type lower]
                set input_signals [get_pins -of  $input_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]

              } else {
                set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
                set input_signals [get_pins -of  $output_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]
              }





              
              
              set floating_signals_num 0
              # echo floating_signals_list
              foreach_in_collection check_pin $input_signals {
                 set pin_name [get_attribute [get_pins $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
                 if {$count == 1} {
                      incr floating_signals_num
                      set floating_signals [get_attribute [get_pins $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
                 }
              }
              
              # input signal number
              set input_signal_num [sizeof_collection  $input_signals ]
              echo "${curr_design} input signal (from $sub_empty_design) num (A): $input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt


              # floating signlas number
              echo "${curr_design} is floating signlas (from $sub_empty_design) num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
              
              # should insert lp cell number
              set should_insert_lp_cell_num [expr $input_signal_num - $floating_signals_num]
              echo "${curr_design} should insert lp cells (from $sub_empty_design) num  (C=A-B): $should_insert_lp_cell_num\n"  >> ../reports/insert_lp_cell_num_check.rpt


          }




          
          incr floating_signals_sum $floating_signals_num
          incr should_insert_lp_cell_sum $should_insert_lp_cell_num
          incr subtop_insert_lp_cell_sum $subtop_insert_lp_cell_num


        }


      }

      if { ($design_top == "right_top") } {
              set top_from_scp_inports [get_ports "*from_noc_bottom* *up_to_right right_dft_test_* *scp_to_ddr_reg*" -filter "direction == in"]
              # input signal number
              set top_from_scp_inports_num [sizeof_collection $top_from_scp_inports  ]
              echo "$design_top input (from scp) signals num (A): $top_from_scp_inports_num" >> ../reports/insert_lp_cell_num_check.rpt

              set top_floating_signals_num 0
              # echo floating_signals_list
              foreach_in_collection check_pin $top_from_scp_inports {
                 set port_name [get_attribute [get_ports $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_ports $port_name]]]
                 if {$count == 1} {
                      incr top_floating_signals_num
                      set floating_signals [get_attribute [get_ports $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${design_top}_floating_signals_list.rpt
                 }
              }


              # floating signlas number
              echo "$design_top input (from scp) is floating signlas  num (B): $top_floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
              
              # should insert lp cell number
              set top_should_insert_lp_cell_num [expr $top_from_scp_inports_num - $top_floating_signals_num]
              echo "$design_top input (from scp) should insert lp cells num  (C=A-B): $top_should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt

              set  insert_lp_cell_num  [sizeof_collection [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*"]]
              echo "$design_top input (from scp)  is inserted lp cells num: $insert_lp_cell_num  \n\n" >> ../reports/insert_lp_cell_num_check.rpt

              incr floating_signals_sum $top_floating_signals_num
              incr should_insert_lp_cell_sum $top_should_insert_lp_cell_num
              incr insert_lp_cell_sum $insert_lp_cell_num              
      }


      #  inserted lp cell number
      current_design ${curr_design}
      set insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
      echo "${curr_design} is inserted lp cells num: $insert_lp_cell_num  \n\n\n\n" >> ../reports/insert_lp_cell_num_check.rpt
      current_design ${design_top}
      incr insert_lp_cell_sum $insert_lp_cell_num


  } 

} 

# sub_designs is empty
} else { 

          set floating_signals_num 0
          if { ($design_top == "inno_ualink_ip_top") || ($design_top == "inno_only_ualink_ip_top") ||($design_top == "inno_112g_eth_rdma_top" )  ||($design_top == "P5_inno_pcie_top_wrapper" )} {
            set noc_check_pins [get_port "SIG_RX* CLK_REF_IN* PCIE_RXN PCIE_RXP" -filter "pin_direction =~ in"]
            set input_signals [remove_from_collection  [get_port *  -filter "pin_direction =~ in"] $noc_check_pins]
          } else {
            set input_signals [get_port * -filter "pin_direction =~ in"]
          }
          # echo floating_signals_list
          foreach_in_collection check_pin $input_signals {
             set port_name [get_attribute [get_ports $check_pin] full_name]
             set count [sizeof_collection [all_fanout -flat -from [get_ports $port_name]]]
             if {$count == 1} {
                  incr floating_signals_num
                  set floating_signals [get_attribute [get_ports $port_name] full_name]
                  echo "$floating_signals" >> ../reports/${design_top}_floating_signals_list.rpt
             }
          }



          # input signal number
          set input_signal_num [sizeof_collection  $input_signals ]
          echo "${design_top} input signal  num (A): $input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt


          # floating signlas number
          echo "${design_top} is floating signlas  num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
          
          # should insert lp cell number
          set should_insert_lp_cell_num [expr $input_signal_num - $floating_signals_num]
          echo "${design_top} should insert lp cells  num  (C=A-B): $should_insert_lp_cell_num\n"  >> ../reports/insert_lp_cell_num_check.rpt

          set insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]

          incr insert_lp_cell_sum $insert_lp_cell_num
          incr floating_signals_sum $floating_signals_num
          incr should_insert_lp_cell_sum $should_insert_lp_cell_num
 

}

set all_sub_insert_lp_cell_sum [expr $insert_lp_cell_sum + $subtop_insert_lp_cell_sum]
 
echo "All sub_module is floating signlas sum : $floating_signals_sum"  >> ../reports/insert_lp_cell_num_check.rpt
echo "All sub_module should insert lp cells sum : $should_insert_lp_cell_sum"  >> ../reports/insert_lp_cell_num_check.rpt
echo "All sub_module is inserted lp cells sum : $all_sub_insert_lp_cell_sum\n"  >> ../reports/insert_lp_cell_num_check.rpt

set top_insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
echo "${design_top} is inserted all lp cells num: $top_insert_lp_cell_num\n\n" >> ../reports/insert_lp_cell_num_check.rpt

set cur_date [sh date +%y%m%d_%H]
echo "$cur_date : ${design_top} is inserted all lp cells num: $top_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check_history.rpt

if {$should_insert_lp_cell_sum != $all_sub_insert_lp_cell_sum} {
  echo "Error: should_insert_lp_cell_sum is not equal to all_sub_insert_lp_cell_sum"
}
if {$top_insert_lp_cell_num != $all_sub_insert_lp_cell_sum} {
  echo "Error: top_insert_lp_cell_num is not equal to all_sub_insert_lp_cell_sum"
}

if {($should_insert_lp_cell_sum == $all_sub_insert_lp_cell_sum) && ($top_insert_lp_cell_num == $all_sub_insert_lp_cell_sum)} {
  echo "Information: Insert lp cells is success"
}
