

if { $design_top == "GP3A_TOP" } {

  set_operating_conditions  sspg_0p7650v_m40c
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0
   set_voltage -obj VDD_TVS 0.675  
   #UP
   set_voltage -obj VDD_SCP 0.675
   set_voltage -obj VDD_UALINK 0.675
   set_voltage -obj VDD_CLK_BUF 0.675
   #BTM
   set_voltage -obj VDD_VPU 0.675
   set_voltage -obj VDD_RDMA 0.675
   set_voltage -obj VDD_PCIE5 0.765
   #LEFT
   set_voltage -obj VDD_DDR0 0.675
   set_voltage -obj VDD_DDR1 0.675
   set_voltage -obj VDD_DDR2 0.675
   set_voltage -obj VDD_DDR3 0.675
   set_voltage -obj VDD_DDR4 0.675
   #RIGHT
   set_voltage -obj VDD_DDR5 0.675
   set_voltage -obj VDD_DDR6 0.675
   set_voltage -obj VDD_DDR7 0.675
   set_voltage -obj VDD_DDR8 0.675
   set_voltage -obj VDD_DDR9 0.675
   # mid
   set_voltage -obj VDD_GPC0 0.765
   set_voltage -obj VDD_GPC1 0.765
   set_voltage -obj VDD_GPC2 0.765
   set_voltage -obj VDD_GPC3 0.765

} elseif { ($design_top == "scp_top_wrap")  } {

   set_operating_conditions  sspg_0p6750v_m40c
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0   
   set_voltage -obj VDD_SCP 0.675

} elseif { ($design_top == "inno_ualink_ip_top") || ($design_top == "inno_only_ualink_ip_top") } {

   set_operating_conditions  sspg_0p6750v_m40c
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS_UALINK 0   
   set_voltage -obj VDD_UALINK 0.675


} elseif { ($design_top == "up_top_wrap")  } {

  set_operating_conditions  sspg_0p7650v_m40c
  
   #UP
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0    
   set_voltage -obj VDD_SCP 0.675
   set_voltage -obj VDD_UALINK 0.675
   set_voltage -obj VDD_CLK_BUF 0.675


} elseif { $design_top == "mid_top_wrap" } {

  set_operating_conditions  sspg_0p7650v_m40c
   # mid
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0  
   set_voltage -obj VDD_GPC0 0.765
   set_voltage -obj VDD_GPC1 0.765
   set_voltage -obj VDD_GPC2 0.765
   set_voltage -obj VDD_GPC3 0.765


} elseif { ($design_top == "gp3a_me_top_wrap")  } {

   set_operating_conditions  sspg_0p6750v_m40c  
   #BTM
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0     
   set_voltage -obj VDD_VPU 0.675

} elseif {  ($design_top == "bottom_top_wrap") } {

  set_operating_conditions  sspg_0p7650v_m40c
   #BTM
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0    
   set_voltage -obj VDD_VPU 0.675
   set_voltage -obj VDD_RDMA 0.675
   # actually is 0.765v
   set_voltage -obj VDD_PCIE5 0.675 
} elseif {  ($design_top == "inno_112g_eth_rdma_top") } {

  set_operating_conditions  sspg_0p6750v_m40c
   #BTM
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS_RDMA 0    
   set_voltage -obj VDD_RDMA 0.675

} elseif {  ($design_top == "P5_inno_pcie_top_wrapper") } {

  set_operating_conditions  sspg_0p7650v_m40c
   #BTM
   set_voltage -obj VDD_MAIN 0.675
   set_voltage -obj VSS_PCIE5 0    
   set_voltage -obj VDD_PCIE5 0.765


} elseif { ($design_top == "inno_ddr_ctrl_phy_ew_top_ip") || ($design_top == "inno_ddr_ctrl_phy_ns_top_ip") } {

   set_operating_conditions  sspg_0p6750v_m40c 
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0     
   set_voltage -obj VDD_DDR 0.675

} elseif {  ($design_top == "left_top") } {

  set_operating_conditions  sspg_0p7650v_m40c
   #LEFT
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0    
   set_voltage -obj VDD_DDR_LEFT 0.675

} elseif { $design_top == "right_top" } {

  set_operating_conditions  sspg_0p7650v_m40c  
   #RIGHT
   set_voltage -obj VDD_MAIN 0.765
   set_voltage -obj VSS 0    
   set_voltage -obj VDD_DDR_RIGHT 0.675
   set_voltage -obj VDD_SCP 0.675
} 
