###############################################################################################################################
###############################################  std cell  ######################################################################
###############################################################################################################################
if { ($design_top == "inno_ddr_ctrl_phy_ew_top_ip") || ($design_top == "inno_ddr_ctrl_phy_ns_top_ip")  } {

    set foundry_search_path         [ list \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_pbk_lvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0067/LIBERTY/pbk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_flk_rvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0096/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_flk_lvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0070/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_mbslk_rvt_c54_V1.04_pkg/FE-Liberty/FE-Liberty_sec250710_0072/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_mbslk_lvt_c54_V1.05_pkg/FE-Liberty/FE-Liberty_sec250710_0068/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_pmk_lvt_c54_V1.00_pkg/FE-Liberty_sec230331_0231/LIBERTY/pmk \
    /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p2v_V1.24_pkg/FE-Liberty/FE-Liberty_sec250605_0024/LIBERTY/NLDM \
    /softs/Synopsys_v2025/syn/X-2025.06-SP5/libraries/syn \
    ]
    
    
    set foundry_library [ list \
    ln04lpp_sc_s6p25t_flk_rvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pbk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pbk_lvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_flk_rvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_flk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_rvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_rvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p7650v_m40c_lvf_dth.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c_lvf_dth.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p6750v_0p7650v_m40c_lvf_dt.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p7650v_0p6750v_m40c_lvf_dt.db_ccs_tn \
    ln04lpp_gpio_lib_t12_sspg_sigcmax_0p6750v_1p0800v_m40c.db \
    ]

} elseif { ($design_top == "left_top") || ($design_top == "right_top") || ($design_top == "GP3A_TOP") } {

    set foundry_search_path         [ list \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_pbk_lvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0067/LIBERTY/pbk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_flk_rvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0096/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_flk_lvt_c54_V1.07_pkg/FE-Liberty/FE-Liberty_sec250710_0070/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_mbslk_rvt_c54_V1.04_pkg/FE-Liberty/FE-Liberty_sec250710_0072/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_mbslk_lvt_c54_V1.05_pkg/FE-Liberty/FE-Liberty_sec250710_0068/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s6p25t_pmk_lvt_c54_V1.00_pkg/FE-Liberty_sec230331_0231/LIBERTY/pmk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_rvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0171/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0170/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_rvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0113/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_lvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0111/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_pmk_lvt_c60_V1.06_pkg/FE-Liberty/FE-Liberty_sec250610_0135/LIBERTY/pmk \
    /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p2v_V1.24_pkg/FE-Liberty/FE-Liberty_sec250605_0024/LIBERTY/NLDM \
    /softs/Synopsys_v2025/syn/X-2025.06-SP5/libraries/syn \
    ]
    
    
    set foundry_library [ list \
    ln04lpp_sc_s6p25t_flk_rvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pbk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pbk_lvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_flk_rvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_flk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_rvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_rvt_c54l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_mbslk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p7650v_m40c_lvf_dth.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p6750v_m40c_lvf_dth.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p6750v_0p7650v_m40c_lvf_dt.db_ccs_tn \
    ln04lpp_sc_s6p25t_pmk_lvt_c54l06_sspg_nominal_max_0p7650v_0p6750v_m40c_lvf_dt.db_ccs_tn \
    ln04lpp_sc_s7p94t_flk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p6750v_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p7650v_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_gpio_lib_t12_sspg_sigcmax_0p6750v_1p0800v_m40c.db \
    ]


} else {
    set foundry_search_path         [ list \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_rvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0171/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0170/LIBERTY/flk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_rvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0113/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_lvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0111/LIBERTY/mbslk \
    /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_pmk_lvt_c60_V1.06_pkg/FE-Liberty/FE-Liberty_sec250610_0135/LIBERTY/pmk \
    /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p2v_V1.24_pkg/FE-Liberty/FE-Liberty_sec250605_0024/LIBERTY/NLDM \
    /softs/Synopsys_v2025/syn/X-2025.06-SP5/libraries/syn \
    ]
    
    
    set foundry_library [ list \
    ln04lpp_sc_s7p94t_flk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_rvt_c60l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_rvt_c60l04_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_mbslk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p6750v_0p7650v_m40c.db_ccs_tn_lvf \
    ln04lpp_sc_s7p94t_pmk_lvt_c60l06_sspg_nominal_max_0p7650v_0p6750v_m40c.db_ccs_tn_lvf \
    ln04lpp_gpio_lib_t12_sspg_sigcmax_0p6750v_1p0800v_m40c.db \
    ]


}

set ip_search_path [list .]
set ip_link_library [list ]


###############################################################################################################################
###############################################  gp3_up  ######################################################################
###############################################################################################################################


if { ($design_top == "inno_ualink_ip_top") || ($design_top == "inno_only_ualink_ip_top")  || ($design_top == "up_top_wrap") || ($design_top == "GP3A_TOP")  } {

lappend ip_search_path {*}[ list \
              ../../db/ualink_db_3/ \
              ../../db/ualink_db_3/sue_db \
              ../../dft_db \
              /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p8v_V1.11_pkg/ln04lpp_gpio_lib_1p8v_FE-Liberty_sec240925_0031/LIBERTY/NLDM/ \
]


lappend ip_link_library {*}[ list \
ln04lpp_gpio_lib_t18_sspg_sigrcmax_0p6750v_1p6200v_m40c.db \
inno_112g_serdes_phy_setup_ss_cmax_T_m40_func0p75v.db \
inno_sue_ctrl_top_scan_shift_lib.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_16384x32m16b4c1_UALINK_SP_16384X32_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_16384x32m16b4c1_UALINK_SP_16384X32_SOC_RAM_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_8192x64m8b4c1_UALINK_SP_8192X64_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_8192x64m8b4c1_UALINK_SP_8192X64_SOC_RAM_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x40m2b1c0_dl_msg_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x42m2b1c0_deskew_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x42m2b1c0_deskew_ram_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x42m2b1c0_deskew_ram_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x42m2b1c0_deskew_ram_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x122m2b1c1_upli_org_wrrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x24m2b1c0_upli_orig_wrrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x32m2b1c0_upli_comp_wrrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x17m4b1c0_rx_origdata_fam_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x17m4b1c0_rx_rdrspdata_fam_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x46m2b1c0_rx_cache_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x46m2b1c0_tx_cache_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x17m4b1c0_rx_odf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x17m4b1c0_rx_rdf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x17m4b1c0_rx_rsp_fam_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x17m4b1c0_rx_wmf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x19m4b1c0_rx_rmf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x20m2b1c0_tagmag_orig_awar_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x32m2b1c0_mmu_orig_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x60m2b1c0_rx_rsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x63m4b1c1_rx_uaf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x92m2b1c1_rx_rcf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x32m2b1c0_stats_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x32m2b1c0_stats_ram_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x32m2b1c0_stats_ram_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x32m2b1c0_stats_ram_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x162m2b1c1_mfd_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x162m2b1c1_mfd_ram_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x162m2b1c1_mfd_ram_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x162m2b1c1_mfd_ram_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x104m2b1c0_axi_comp_awar_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x112m2b1c0_axi_orig_awar_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x162m2b1c1_tx_dbuf_origdata_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x166m2b1c1_axi_orig_comp_w_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x168m2b1c1_cpl_origdbuf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x168m2b1c1_upli_orig_comp_orgdata_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x176m2b1c1_upli_org_rdrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x214m2b1c1_cpl_reqbuf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x214m2b1c1_upli_orig_comp_req_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x256m2b1c1_retry_queue_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x260m2b1c1_mfo_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x260m2b1c1_mfo_ram_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x260m2b1c1_mfo_ram_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x260m2b1c1_mfo_ram_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x288m2b1c1_tx_dbuf_rdrsp_data_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x300m2b1c1_axi_orig_comp_r_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x304m2b1c1_upli_orig_rdrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x314m2b1c1_upli_comp_rdrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_256x288m2b1c1_retry_txbuf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_512x18m2b1c0_msg_orig_comp_rdrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_512x258m2b1c1_rx_data_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_512x288m2b1c1_rx_obf_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_512x298m2b1c1_atomic_comp_rdrsp_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_512x30m2b1c0_axid_allocate_comp_awar_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x160m1b2c1_sdtxrx_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x160m1b2c1_sdtxrx_ram_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x160m1b2c1_sdtxrx_ram_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x160m1b2c1_sdtxrx_ram_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_32x288m1b2c1_dl_rx_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_8x288m1b2c1_dl_tx_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_rvt_32x12m1b2c0_UALINK_DP2_12X32_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_rvt_32x12m1b2c0_UALINK_DP2_12X32_SOC_RAM_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x22m4b1c1_StdRam1R1W1024D22WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x22m4b1c1_StdRam1R1W1024D22WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x22m4b1c1_StdRam1R1W1024D22WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x22m4b1c1_StdRam1R1W1024D22WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x30m4b1c1_StdRam1R1W1024D30WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x30m4b1c1_StdRam1R1W1024D30WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x30m4b1c1_StdRam1R1W1024D30WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x30m4b1c1_StdRam1R1W1024D30WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x80m4b1c1_StdRam1R1W1024D80WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x80m4b1c1_StdRam1R1W1024D80WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x80m4b1c1_StdRam1R1W1024D80WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x80m4b1c1_StdRam1R1W1024D80WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x108m2b1c1_StdRam1R1W128D108WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x108m2b1c1_StdRam1R1W128D108WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x108m2b1c1_StdRam1R1W128D108WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x108m2b1c1_StdRam1R1W128D108WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x110m2b1c1_StdRam1R1W128D110WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x110m2b1c1_StdRam1R1W128D110WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x110m2b1c1_StdRam1R1W128D110WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x110m2b1c1_StdRam1R1W128D110WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x122m2b1c1_StdRam1R1W128D122WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x122m2b1c1_StdRam1R1W128D122WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x122m2b1c1_StdRam1R1W128D122WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x122m2b1c1_StdRam1R1W128D122WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x58m2b1c1_StdRam1R1W128D58WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x58m2b1c1_StdRam1R1W128D58WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x58m2b1c1_StdRam1R1W128D58WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x58m2b1c1_StdRam1R1W128D58WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_160x82m2b1c1_StdRam1R1W160D82W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_160x82m2b1c1_StdRam1R1W160D82W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_160x82m2b1c1_StdRam1R1W160D82W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_160x82m2b1c1_StdRam1R1W160D82W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x110m2b1c1_StdRam1R1W16D110W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x110m2b1c1_StdRam1R1W16D110W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x110m2b1c1_StdRam1R1W16D110W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x110m2b1c1_StdRam1R1W16D110W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x130m2b1c1_StdRam1R1W16D130W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x130m2b1c1_StdRam1R1W16D130W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x130m2b1c1_StdRam1R1W16D130W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x130m2b1c1_StdRam1R1W16D130W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x140m2b1c1_StdRam1R1W16D140W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x140m2b1c1_StdRam1R1W16D140W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x140m2b1c1_StdRam1R1W16D140W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x140m2b1c1_StdRam1R1W16D140W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x146m2b1c1_StdRam1R1W16D146W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x146m2b1c1_StdRam1R1W16D146W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x146m2b1c1_StdRam1R1W16D146W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_16x146m2b1c1_StdRam1R1W16D146W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x40m2b1c1_StdRam1R1W256D39WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x40m2b1c1_StdRam1R1W256D39WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x40m2b1c1_StdRam1R1W256D39WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x40m2b1c1_StdRam1R1W256D39WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x130m2b1c1_StdRam1R1W32D130WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x130m2b1c1_StdRam1R1W32D130WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x130m2b1c1_StdRam1R1W32D130WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x130m2b1c1_StdRam1R1W32D130WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x134m2b1c1_StdRam1R1W32D134WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x134m2b1c1_StdRam1R1W32D134WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x134m2b1c1_StdRam1R1W32D134WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_32x134m2b1c1_StdRam1R1W32D134WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_384x12m4b1c1_StdRam1R1W384D12W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_384x12m4b1c1_StdRam1R1W384D12W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_384x12m4b1c1_StdRam1R1W384D12W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_384x12m4b1c1_StdRam1R1W384D12W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x138m2b1c1_StdRam1R1W512D138WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x138m2b1c1_StdRam1R1W512D138WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x138m2b1c1_StdRam1R1W512D138WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x138m2b1c1_StdRam1R1W512D138WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x15m4b1c1_StdRam1R1W512D15WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x15m4b1c1_StdRam1R1W512D15WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x15m4b1c1_StdRam1R1W512D15WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x15m4b1c1_StdRam1R1W512D15WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x28m4b1c1_StdRam1R1W512D28WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x28m4b1c1_StdRam1R1W512D28WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x28m4b1c1_StdRam1R1W512D28WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x28m4b1c1_StdRam1R1W512D28WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x29m4b1c1_StdRam1R1W512D29WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x29m4b1c1_StdRam1R1W512D29WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x29m4b1c1_StdRam1R1W512D29WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x29m4b1c1_StdRam1R1W512D29WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_56x150m2b1c1_StdRam1R1W50D150W_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_56x150m2b1c1_StdRam1R1W50D150W_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_56x150m2b1c1_StdRam1R1W50D150W_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_56x150m2b1c1_StdRam1R1W50D150W_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x146m2b1c1_StdRam1R1W64D146WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x146m2b1c1_StdRam1R1W64D146WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x146m2b1c1_StdRam1R1W64D146WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x146m2b1c1_StdRam1R1W64D146WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x152m2b1c1_StdRam1R1W64D152WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x152m2b1c1_StdRam1R1W64D152WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x152m2b1c1_StdRam1R1W64D152WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x152m2b1c1_StdRam1R1W64D152WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_72x76m2b1c1_StdRam1R1W72D75WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_72x76m2b1c1_StdRam1R1W72D75WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_72x76m2b1c1_StdRam1R1W72D75WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_72x76m2b1c1_StdRam1R1W72D75WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_88x76m2b1c1_StdRam1R1W88D75WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_88x76m2b1c1_StdRam1R1W88D75WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_88x76m2b1c1_StdRam1R1W88D75WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_88x76m2b1c1_StdRam1R1W88D75WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_96x110m2b1c1_StdRam1R1W96D110WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_96x110m2b1c1_StdRam1R1W96D110WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_96x110m2b1c1_StdRam1R1W96D110WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_96x110m2b1c1_StdRam1R1W96D110WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rws_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rws_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rws_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rws_hsr_rvt_512x140m2b1c1_StdRam1R1WDm512D140WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_rvt_256x148m2b1c1_StdRam1RW256D148WFlopOut_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
]


} 
if { ($design_top == "scp_top_wrap") || ($design_top == "up_top_wrap") || ($design_top == "GP3A_TOP")  } {


lappend ip_search_path {*}[ list \
              $GP3_RTL/scp/syn_lib \
              $GP3_RTL/lowspeed/syn_lib/lib_db \
              $GP3_RTL/tvsensor/syn_lib/0p75/db/ \
              $GP3_RTL/risc_v/syn_lib/memory \
              $GP3_RTL/scp/rtl/trust_engine/memory/memory_lib \
              /home/Storage_Plugins/Backend/meijx/GP3A_prj/macro_data/ip/db \
]


lappend ip_link_library {*}[ list \
ln04lpp_s00_mc_vromp_hd_lvt_4096x32m16b2c1_sspg_sigrcmax_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_uhdrw_lvt_4096x32m8b2c1_CPU_RAM_4096X32_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_512x128m2b1c1_GP3_ACA_SP_512X128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_128x32m2b1c1_EC_RAM_128X32_S4_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
INNO_FNPLL_TOP_setup_ss_rcmax_T_m40.db \
inno_por_ip_setup_ss_rcmax_T_m40_func.db \
sf_efuse4kb_s201_ln04lpp_3205000_sspg_sigrcmin_0p6750v_m40c.db \
inno_tsensor_ip_setup_ss_cmax_m40_func0p75v.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_528x32m4b1c0_GP3_CTX_SP_528X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
sf_efuse8kb_s201_ln04lpp_3205000_sspg_sigrcmin_0p6750v_m40c.db \
]




} 
if { ($design_top == "up_top_wrap") || ($design_top == "GP3A_TOP")   } {

if {$tool == "FM"} {
    set ip_search_path         [ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
                  $GP3_RTL/ualink/syn_lib/db \
                  /home/Storage_Plugins/Backend/meijx/GP3A_prj/macro_data/ip/db \
                  $GP3_RTL/coresight/mem_lib \
    ]
    
    set ip_link_library [ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    inno_ualink_refclkbuffer_top_setup_ss_rcmin_T_m40.db \
    sf_efuse8kb_s201_ln04lpp_3205000_sspg_sigrcmin_0p6750v_m40c.db \
    ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ]
    

} else {

    lappend ip_search_path {*}[ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
                  $GP3_RTL/ualink/syn_lib/db \
                  /home/Storage_Plugins/Backend/meijx/GP3A_prj/macro_data/ip/db \
                  $GP3_RTL/coresight/mem_lib \
    ]
    
    lappend ip_link_library {*}[ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    inno_ualink_refclkbuffer_top_setup_ss_rcmin_T_m40.db \
    sf_efuse8kb_s201_ln04lpp_3205000_sspg_sigrcmin_0p6750v_m40c.db \
    ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ]
}


} 

###############################################################################################################################
###############################################  gp3_mid  ######################################################################
###############################################################################################################################

if { $design_top == "mid_top_wrap" || ($design_top == "GP3A_TOP")  } {

lappend ip_search_path {*}[ list \
              $GP3_RTL/tvsensor/syn_lib/0p75/db/ \
              $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
              $GP3_RTL/coresight/mem_lib \
              $GP3_RTL/top/syn_lib \              
]


lappend ip_link_library {*}[ list \
inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
inno_tsensor_ip_setup_ss_cmax_m40_func0p75v.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_32x128m1b2c1_GPC_REPACK_32X128_sspg_sigcmax_0p7650v_0p7650v_m40c_lvf.db \
]
} 
###############################################################################################################################
###############################################  gp3_btm  ######################################################################
###############################################################################################################################
if { $design_top == "P5_inno_pcie_top_wrapper" || $design_top == "bottom_top_wrap" || ($design_top == "GP3A_TOP") } {

lappend ip_search_path {*}[ list \
  /home/Storage_Plugins/Frontend/zhangl/GP3_2025/GPUHW/code/flow_run/design/syn/soc/P5_syn_inno_pcie_top_wrapper_0613/scr/libtodb_scr \
               $GP3_RTL/tvsensor/syn_lib/0p85/db/ \

]



lappend ip_link_library {*}[ list \
ln04lpp_s00_mc_rf2rws_hsr_lvt_16x128m1b2c1_PCIE_ATOMIC_16X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
inno_pcie_phy_setup_ss_cmax_T_m40_func0p85v.db \
inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x134m2b1c1_P5_U_IB_MCPL_SB_RAM_DP1_D128_W134_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x148m2b1c1_P5_U_IB_RREQ_ORDR_RAM_DP1_D128_W148_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_248x130m2b1c1_P5_U3_RAM_RADM_QBUFFER_DATA_DP1_D248_W130_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_48x142m2b1c1_P5_U0_RAM_RADM_QBUFFER_HDR_DP1_D48_W142_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x130m2b1c1_P5_U3_RAM_RADM_QBUFFER_DATA_DP1_D512_W130_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x134m2b1c1_P5_U_IB_MCPL_SB_RAM_DP1_D512_W134_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x142m2b1c1_P5_U0_RAM_RADM_QBUFFER_HDR_DP1_D512_W142_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_uhdrw_lvt_16x144m2b1c1_P5_SLV_WFIFO_DP1_D16_W144_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_uhdrw_lvt_24x64m2b1c0_P5_U_RAM_CDM_RASDES_EC_REG_DP1_D24_W64_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_uhdrw_lvt_512x12m4b1c0_P5_U_RAM_2P_SOTBUF_DP1_D512_W12_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_uhdrw_lvt_512x40m4b1c0_P5_ATS_4K_DP1_D512_W40_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x182m2b1c1_P5_U_SLV_NPW_SAB_RAM_DP1_D64_W182_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rws_uhsr_lvt_256x260m2b1c1_noc_gen6_dp1clk_256_260_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rd2rws_uhsr_lvt_96x84m2b1c1_noc_gen6_dp1clk_96_84_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_120x136m2b1c1_P5_U_RAM_1P_RBUF_SP_D120_W136_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_512x136m2b1c1_P5_U_RAM_1P_RBUF_SP_D512_W136_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x132m1b2c1_P5_U_OB_PDCMP_HDR_RAM_DP2_D16_W132_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x156m1b2c1_P5_U_IB_RREQ_C2A_CDC_RAM_DP2_D16_W156_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_256x128m1b4c1_P5_U_OB_CCMP_DATA_RAM_DP2_D256_W128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_256x140m1b4c1_P5_U_OB_CCMP_DATA_RAM_DP2_D256_W140_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_512x128m1b8c1_P5_U_OB_CCMP_DATA_RAM_DP2_D512_W128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_hsr_lvt_512x140m1b8c1_P5_U_OB_CCMP_DATA_RAM_DP2_D512_W140_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_16x220m1b2c1_P5_U_IB_MCPL_A2C_CDC_RAM_DP2_D16_W220_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_16x224m1b2c1_P5_U_IB_WREQ_C2A_CDC_RAM_DP2_D16_W224_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_256x204m1b4c1_P5_U_OB_NPDCMP_RAM_DP2_D256_W204_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_40x256m1b2c1_P5_U_OB_PDCMP_DATA_RAM_DP2_D40_W256_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
ln04lpp_s00_mc_rf2rws_hsr_lvt_16x128m1b2c1_PCIE_ATOMIC_16X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db  \
]


} 
if { $design_top == "gp3a_me_top_wrap" || $design_top == "bottom_top_wrap" || ($design_top == "GP3A_TOP") } {

lappend ip_search_path {*}[ list \
              $GP3_RTL/vcodec/vdec/syn_lib/memory_db \
              $GP3_RTL/vcodec/axi_mmu/syn_lib/db \
              $GP3_RTL/../../../flow_run/design/syn/soc/syn_jpeg/scr/libtodb_scr \
              $GP3_RTL/../../../core/design/flow/macros/samsung4lpp/mss/db \
]


lappend ip_link_library {*}[ list \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x64m1b2c0_SS4LPP_WAVE517_DP_64X64_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_144x160m2b1c1_SS4LPP_WAVE517_SP_144X160_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_192x80m2b1c0_SS4LPP_WAVE517_SP_192X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_80x30m2b1c0_SS4LPP_WAVE517_SP_80X30_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_80x50m2b1c0_SS4LPP_WAVE517_SP_80X50_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_96x80m2b1c0_SS4LPP_WAVE517_SP_96X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_256x160m2b1c1_SS4LPP_WAVE517_SPSRAM_256X160_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_512x80m2b1c1_SS4LPP_WAVE517_SPSRAM_512X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_116x80m1b2c0_SS4LPP_WAVE517_DP_114X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_64x40m1b2c0_SS4LPP_WAVE517_DP_64X40_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_80x64m1b2c0_SS4LPP_WAVE517_DP_80X64_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_128x32m2b1c0_SS4LPP_WAVE517_SP_128X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_512x32m4b1c0_SS4LPP_WAVE517_SP_512X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_40x32m2b1c0_SS4LPP_WAVE517_SP_40X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_lvt_576x128m4b2c1_SS4LPP_WAVE517_SP_576X128_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_64x64m1b2c0_SS4LPP_WAVE517_DP_64X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x64m1b2c0_SS4LPP_WAVE517_DP_16X64_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_256x64m2b1c0_SS4LPP_WAVE517_SP_256X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_1024x32m4b1c0_SS4LPP_WAVE517_SP_1024X32_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_64x42m2b1c0_SS4LPP_WAVE517_SP_64X42_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_240x16m1b4c0_SS4LPP_WAVE517_DP_240X16_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_128x72m1b2c0_SS4LPP_WAVE517_DP_128X72_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_192x16m1b4c0_SS4LPP_WAVE517_DP_192X16_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x32m1b2c0_SS4LPP_WAVE517_DP_128X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_136x16m1b4c0_SS4LPP_WAVE517_DP_136X16_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_128x64m1b2c0_SS4LPP_WAVE517_DP_128X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_32x22m2b1c0_SS4LPP_WAVE517_SP_32X22_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_184x160m2b1c1_SS4LPP_WAVE517_SP_184X160_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_16x160m2b1c1_SS4LPP_WAVE517_SP_15X160_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_64x80m1b2c0_SS4LPP_WAVE517_DP_64X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_32x80m1b2c0_SS4LPP_WAVE517_DP_32X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_64x160m2b1c1_SS4LPP_WAVE517_SP_64X160_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_80x64m1b2c0_SS4LPP_WAVE517_DP_80X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x80m1b2c0_SS4LPP_WAVE517_DP_64X80_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_512x128m2b1c1_SS4LPP_WAVE517_SPSRAM_512X128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_512x28m4b1c0_SS4LPP_WAVE517_SPSRAM_512X28_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_384x128m2b1c1_SS4LPP_WAVE517_SPSRAM_384X128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_64x46m2b1c0_SS4LPP_WAVE517_SP_64X45_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rs_hsr_lvt_1024x128m4b2c1_SS4LPP_WAVE517_SPSRAM_1024X128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x72m1b2c0_SS4LPP_WAVE517_DP_128X69_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x64m1b2c0_SS4LPP_WAVE517_DP_128X64_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x60m1b2c0_SS4LPP_WAVE517_DP_64X57_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x64m1b2c0_SS4LPP_WAVE517_DP_128X61_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_40x68m1b2c0_SS4LPP_WAVE517_DP_38X68_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_208x16m1b4c0_SS4LPP_WAVE517_DP_207X16_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x20m1b2c0_SS4LPP_WAVE517_DP_128X20_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_48x80m1b2c0_SS4LPP_WAVE517_DP_48X80_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_48x80m1b2c0_SS4LPP_WAVE517_DP_48X80_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_128x88m2b1c1_SS4LPP_WAVE517_SP_128X88_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_256x88m2b1c1_SS4LPP_WAVE517_SP_256X88_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rws_uhdrw_lvt_512x64m2b1c0_SS4LPP_WAVE517_SPSRAM_512X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_128x16m4b1c0_SS4LPP_WAVE517_SP_128X16_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x40m1b2c0_SS4LPP_WAVE517_DP_64X40_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_lvt_32x64m1b2c0_SS4LPP_WAVE517_DP_32X64_BWEB_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_64x32m2b1c0_SS4LPP_WAVE517_SP_64X32_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_uhdrw_lvt_512x16m4b1c0_SS4LPP_WAVE517_SPSRAM_512X16_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rs_uhdrw_lvt_4096x16m16b2c1_SS4LPP_WAVE517_SPSRAM_4096X16_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x130m2b1c0_SS4LPP_WAVE517_DP1CK_64X129_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x128m2b1c0_SS4LPP_WAVE517_DP1CK_64X128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_128x72m1b2c0_SS4LPP_WAVE517_DP_128X72_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_336x8m4b1c1_JPEG_SP_336X8_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_64x12m4b1c1_JPEG_SP_64X12_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_384x12m4b1c1_JPEG_SP_384X12_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_416x8m4b1c1_JPEG_SP_416X8_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_256x8m4b1c1_JPEG_SP_256X8_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_256x16m4b1c1_JPEG_SP_256X16_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rs_hsr_lvt_2048x8m8b2c1_JPEG_SP_2048X8_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_256x128m2b1c1_JPEG_SP_256X128_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x42m2b1c1_GPU_DP_128X42_P42_ID1003_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x56m2b1c1_GPU_DP_64X55_P55_ID1002_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
]


} 
if { $design_top == "inno_112g_eth_rdma_top" || $design_top == "bottom_top_wrap" || ($design_top == "GP3A_TOP") } {

lappend ip_search_path {*}[ list \
   /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p8v_V1.18_pkg/FE-Liberty/FE-Liberty_sec251224_0071/LIBERTY/NLDM_LVF \
   $GP3_RTL/../../../flow_run/design/upf/db/rdma/library/mac_mem/mem_db/ \
   $GP3_RTL/../../../flow_run/design/upf/db/rdma/library/rdma_mem/mem_db/ \
   $GP3_RTL/../../../flow_run/design/upf/db/rdma/library/pma_lib_db/ \
   $GP3_RTL/../../../flow_run/design/upf/db/rdma/library/ss4_mem_pma_layer/mem_db/ \
   $GP3_RTL/../../../flow_run/design/upf/db/rdma/library/ss4_mem_pcs_layer/mem_db/ \
]

lappend ip_link_library {*}[ list \
ln04lpp_gpio_lib_t18_sspg_sigrcmax_0p6750v_1p0800v_125c_lvf_dt.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x128m1b2c1_ss4_eth_txd_2prf_64x128_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_64x140m1b2c1_ss4_eth_rxd_2prf_64x140_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x10m4b1c1_ALPHA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x10m4b1c1_T_BC_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_CQ_HEAD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_CQ_TAIL_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_RCQ_HEAD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_RQ_HEAD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_RQ_TAIL_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_SQ_HEAD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_SQ_TAIL_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x13m4b1c1_SW_RQ_HEAD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_CC_RATE_MEM_bank0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_CC_RATE_MEM_bank1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_CC_RATE_MEM_bank2_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_CC_RATE_MEM_bank3_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_NOCNP_TIMER_MEM0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_NOCNP_TIMER_MEM1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_NOCNP_TIMER_MEM2_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_NOCNP_TIMER_MEM3_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_UDP_SRC_PORT_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_UPD_ALPHA_MEM0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_UPD_ALPHA_MEM1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_UPD_ALPHA_MEM2_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x16m4b1c1_UPD_ALPHA_MEM3_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x17m4b1c1_CNP_MERGE_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x17m4b1c1_RATE_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_BYTE_COUNTER_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_EXPECT_RESP_PSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_EXPECT_RX_MSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_MR_PD_NUM_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_PSN_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_QP_PD_NUM_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_SQ_PSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_TX_LAST_PSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_TX_RETRY_EPSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x24m4b1c1_WQE_SSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x25m4b1c1_RQ_REQ_INFO_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x25m4b1c1_TX_ACK_SN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x27m4b1c1_QP_CFG_EN_RX_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x27m4b1c1_QP_CFG_EN_TX_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_CC_BYTE_CNT_MEM_bank0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_CC_BYTE_CNT_MEM_bank1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_CC_BYTE_CNT_MEM_bank2_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_CC_BYTE_CNT_MEM_bank3_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_CQ_BA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_DEST_MAC_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_MR_LEN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_MR_PHY_ADDR_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_MR_VIR_ADDR_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_QP_STATUS_RSV_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RCQ_BA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RD_REQ_USER_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_READ_LADDR_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RETRY_TMO_MEM0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RETRY_TMO_MEM1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RETRY_TMO_MEM2_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RETRY_TMO_MEM3_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RQ_BA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_RQ_DB_ADDR_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x32m4b1c1_SQ_BA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x34m4b1c1_DEST_IP_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x34m4b1c1_SEND_CHK_RQ_STA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x41m4b1c1_OSQ_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x42m4b1c1_CQ_DESC_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x64m4b1c1_WR_BA_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x8m4b1c1_MAX_FW_MSN_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_1024x9m4b1c1_RQ_INFO_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x128m2b1c1_WQE_DMA_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x144m2b1c1_REQ_WR_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x144m2b1c1_WQE_DAT_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x26m2b1c1_ACKCNP_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x72m2b1c1_AXI_MULTI_WR_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x72m2b1c1_CQ_AXI_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x104m2b1c1_RCQE_INFO_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x112m2b1c1_CMD_INFO_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x128m2b1c1_AXI_CMD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x25m4b1c1_TX_F2M_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_256x94m2b1c1_RD_RESP_INFO_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x128m2b1c1_CMD_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x128m2b1c1_NONR_TX_ORD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x128m2b1c1_RX_REQ_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x128m2b1c1_TX_DMA_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x130m2b1c1_RX_DAT_BUF_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_512x154m2b1c1_REQ_SYND_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x128m2b1c1_NONR_MD_ORD_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x128m2b1c1_NONR_RX_MD_RD_MEM0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x128m2b1c1_NONR_RX_MD_RD_MEM1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x128m2b1c1_NONR_TX_MD_RD_MEM0_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x128m2b1c1_NONR_TX_MD_RD_MEM1_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x130m2b1c1_NONR_RX_AXI_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x132m2b1c1_NONR_TX_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x134m2b1c1_NONR_RX_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x26m2b1c1_RCQE_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x30m2b1c1_CQ_OST_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x52m2b1c1_DCQCN_DFX_INFO_MEM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_128x42m2b1c0_deskew_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_hsr_rvt_64x32m2b1c0_stats_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x162m2b1c1_mfd_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_16x260m2b1c1_mfo_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_hsr_lvt_16x160m1b2c1_sdtxrx_ram_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_8192x64m8b4c1_UALINK_SP_8192X64_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_ra1rws_hsr_rvt_16384x32m16b4c1_UALINK_SP_16384X32_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rws_hsr_rvt_32x12m1b2c0_UALINK_DP2_12X32_SOC_RAM_sspg_sigrcmax_0p6750v_0p6750v_m40c_lvf.db \
inno_112g_serdes_phy_setup_ss_cmax_T_m40_func0p75v.db \
]

} 
if { $design_top == "bottom_top_wrap"  || ($design_top == "GP3A_TOP") } {


if {$tool == "FM"} {  
    set ip_search_path         [ list \
                  $GP3_RTL/coresight/mem_lib \
                  $GP3_RTL/../../../flow_run/design/upf/db/db_0515 \
                  $GP3_RTL/../../../flow_run/design/upf/db \
    ]
    
    
    
    set ip_link_library [ list \
    ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x42m2b1c1_GPU_DP_128X42_P42_ID1003_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x56m2b1c1_GPU_DP_64X55_P55_ID1002_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rf2rs_hsr_lvt_128x72m1b2c0_SS4LPP_AXIMMU_RISCV_DP_128X72_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    inno_refclkbuffer_1to1_top.setup_ss_rcmin_T_m40_func0p75v.db \
    ]

} else {
    lappend ip_search_path {*}[ list \
                  $GP3_RTL/coresight/mem_lib \
                  $GP3_RTL/../../../flow_run/design/upf/db/db_0515 \
                  $GP3_RTL/../../../flow_run/design/upf/db \
    ]
    
    
    
    lappend ip_link_library {*}[ list \
    ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x42m2b1c1_GPU_DP_128X42_P42_ID1003_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x56m2b1c1_GPU_DP_64X55_P55_ID1002_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    ln04lpp_s00_mc_rf2rs_hsr_lvt_128x72m1b2c0_SS4LPP_AXIMMU_RISCV_DP_128X72_sspg_sigrcmax_0p7650v_0p7650v_m40c_lvf.db \
    inno_refclkbuffer_1to1_top.setup_ss_rcmin_T_m40_func0p75v.db \
    ]
}
}
###############################################################################################################################
###############################################  gp3_left  ######################################################################
###############################################################################################################################
if { ($design_top == "inno_ddr_ctrl_phy_ew_top_ip") || ($design_top == "inno_ddr_ctrl_phy_ns_top_ip") || ($design_top == "left_top") || ($design_top == "right_top") || ($design_top == "GP3A_TOP") } {

lappend ip_search_path {*}[ list \
              /home/Storage_Plugins/Backend/mengfp/GP3A_prj/macro_data/memory/db/inno_combo_memory_ctrl_ip \
              /home/Storage_Plugins/Backend/mengfp/GP3A_prj/macro_data/memory/db/inno_ddr_ctrl_phy_ew_top_ip \
              /home/Storage_Plugins/Backend/mengfp/GP3A_prj/macro_data/memory/db/inno_ddr_ctrl_phy_ns_top_ip \
              /home/Storage_Plugins/Backend/mengfp/GP3A_prj/frontend_package/ddr_ctrl/1x_ctrl/1217/mem/ln04lpp_s00_mc_rf1rs_hsr_lvt_16x80m2b1c1_DDR_SP_16X80 \
              /Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p8v_V1.18_pkg/FE-Liberty/FE-Liberty_sec251224_0071/LIBERTY/NLDM \
]
#              $GP3_RTL/../../../flow_run/design/upf/dft_db \

lappend ip_link_library {*}[ list \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x44m2b1c1_DDR_DP_128X44_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_128x52m2b1c1_DDR_DP_128X52_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_256x52m2b1c1_DDR_DP_256X52_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rs_uhsr_lvt_256x64m2b1c1_DDR_DP_256X64_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rd2rws_uhsr_lvt_256x64m2b1c1_DDR_DP_256X64_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf1rs_hsr_lvt_16x80m2b1c1_DDR_SP_16X80_sspg_sigcmax_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_128x52m1b4c1_DDR_DP_128X52_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_s00_mc_rf2rs_uhsr_lvt_128x64m1b4c1_DDR_DP_128X64_sspg_sigrcmin_0p6750v_0p6750v_m40c_lvf.db \
ln04lpp_gpio_lib_t18_sspg_sigcmax_0p6750v_1p6200v_m40c.db \
]
#left_top_scan_shift_lib.db \



}
 if { $design_top == "left_top"  || ($design_top == "GP3A_TOP") } {

if {$tool == "FM"} {
    set ip_search_path         [ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
    ]
    
    set ip_link_library [ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    ]
} else {
    lappend ip_search_path {*}[ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
    ]
    
    lappend ip_link_library {*}[ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    ]

}  
}
###############################################################################################################################
###############################################  gp3_right  ######################################################################
###############################################################################################################################
 if { $design_top == "right_top"  || ($design_top == "GP3A_TOP") } {



if {$tool == "FM"} {
    set ip_search_path         [ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
    ]
    
    set ip_link_library [ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    ]
} else {
    lappend ip_search_path {*}[ list \
                  $GP3_RTL/tvsensor/syn_lib/0p85/db/ \
    ]
    
    lappend ip_link_library {*}[ list \
    inno_tsensor_ip_setup_ss_cmax_m40_func0p85v.db \
    ]

}  




}
###############################################################################################################################
###############################################  gp3_top  ######################################################################
###############################################################################################################################
if {$design_top == "GP3A_TOP"} {
lappend ip_search_path {*}[ list \
]


lappend ip_link_library {*}[ list \
]


} 
###############################################################################################################################
###############################################  set lib  ######################################################################
###############################################################################################################################
set_app_var search_path         [concat $foundry_search_path $ip_search_path]
set synthetic_library   [list dw_foundation.sldb standard.sldb]

if {$tool == "FM"} {
read_db "$foundry_library $ip_link_library $synthetic_library"
} else {
#set_app_var target_library      $foundry_library
set_app_var link_library " $foundry_library $ip_link_library $synthetic_library"
}
