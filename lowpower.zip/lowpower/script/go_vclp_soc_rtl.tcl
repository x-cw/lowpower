# GLOBAL VARIABLES
sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

set REPORTS_DIR ../reports/upf_check
#setenv UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
#set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
#setenv GP3_RTL /home/Storage_Plugins/xucw/work/GP3/GPUHW/code/soc/design/src
#setenv DESIGN_SRC /home/Storage_Plugins/xucw/work/GP3/GPUHW/code/core/design/src
#setenv G_RTL_ROOT /home/Storage_Plugins/xucw/work/GP3/GPUHW/code/core/design
#setenv G_FLST_ROOT /home/Storage_Plugins/xucw/work/GP3/GPUHW/code/core/design/filelist
set GP3_RTL /home/Storage_Plugins/Frontend/xucw/GP3/GPUHW/code/soc/design/src

# read_verilog command option
set READ_OPT "-netlist"
set tool "vc-lp"
set do_restart_session "false"


set design_top  $DESIGN_TOP


# REPORTS
if !{[file exists $REPORTS_DIR]} {
  sh mkdir -p $REPORTS_DIR
}

# SETUP
source ../script/synopsys_vcst.setup

# HETEROGENEOUS FANOUT
set upf_hetero_fanout_isolation true

if { $do_restart_session == "false" } {

echo "info: start read netlist"
#---------------------------------------------------------------------
#                  read lib/db
#---------------------------------------------------------------------


source ../script/read_dft_db.tcl

#---------------------------------------------------------------------
#                  auto_bbox
#---------------------------------------------------------------------

#enable_rca_cluster -app lp 

set_app_var enable_auto_bbox_identification true
#if {[file exists ../run/out_bbox.tcl]}  {
#   source ../run/out_bbox.tcl
#}
#---------------------------------------------------------------------
#                  read rtl
#---------------------------------------------------------------------
# READ RTL
analyze -f sverilog -vcs "+warn=noPHNE -timescale=1ns/1ps -f ../script/rtl_filelist/${design_top}_rtl.f"



#---------------------------------------------------------------------
#                  link
#---------------------------------------------------------------------

current_design ${design_top}
#link
elaborate ${design_top} -j 16 -vcs "+warn=noSM_DNS +lint=TFIPC-L"


#enable_lp_dump_debug_reports  -dump_decompile_upf -dump_crossover -dump_crossover_through_info 5


checkpoint_session -session Session_Read_Rtl_Design

} elseif { $do_restart_session == "true" } {
echo "info: restart session"
restart_session -session Session_Read_Rtl_Design
}

#execute_rootcause_analysis -app lp

#---------------------------------------------------------------------
#                  read upf
#---------------------------------------------------------------------
# LOAD UPF, use report_read to simplify messaging
load_upf ../upf/${design_top}.upf -j 16
#---------------------------------------------------------------------
#                  identify_lp_blackboxes
#---------------------------------------------------------------------
identify_lp_blackboxes -file ../run/out_bbox.tcl

#generate_crossovers -j 16

#enable_lp_dump_debug_reports   -dump_crossover_through_info 5





#---------------------------------------------------------------------
#                  configure_lp_tag
#---------------------------------------------------------------------

report_violation

#waive list/disable rule
configure_lp_tag -tag ISO_STRATEGY_NOISO -severity warning
configure_lp_tag -tag UPF_CSN_MACRO -disable
configure_lp_tag -tag UPF_CSN_PAD -disable


#---------------------------------------------------------------------
#                  waive
#---------------------------------------------------------------------
set default_waiver_file   ../script/waive_list_rtl/${design_top}_awl.tcl
source ../script/waive_list_rtl/${design_top}_awl.tcl


#---------------------------------------------------------------------
#                  report
#---------------------------------------------------------------------


# CHECK/REPORT
redirect -file $REPORTS_DIR/rtl_check_lp.${design_top}.upf.rpt {check_lp -stage upf  -j 16}
#check_lp -stage upf
redirect -file $REPORTS_DIR/rtl_report_lp.${design_top}.list.rpt {report_lp -list}

redirect -file $REPORTS_DIR/rtl_check_lp.${design_top}.ls.rpt {check_lp -stage upf -family levelshifter -j 16}

#execute_rootcause_analysis -app lp

#save_session
sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

start_gui
#exit
