
###############################################################################################################################
###############################################  gp3_top  ######################################################################
###############################################################################################################################

if {$design_top == "GP3A_TOP"} {


###############################################################################################################################
###############################################  gp3_up  ######################################################################
###############################################################################################################################

} elseif { $design_top == "inno_ualink_ip_top" } {


} elseif { $design_top == "scp_top_wrap" } {

} elseif { $design_top == "inno_ualink_ip_top" } {

} elseif { $design_top == "inno_only_ualink_ip_top" } {


} elseif { $design_top == "up_top_wrap" } {

set_constant -type port r:/WORK/${design_top}/noc_up_wrap_inst0/reg_isolation_ulk0_up_glue 0
set_constant -type port r:/WORK/${design_top}/noc_up_wrap_inst1/reg_isolation_ulk0_scp_glue 0

set_constant -type port i:/WORK/${design_top}/noc_up_wrap_inst0/reg_isolation_ulk0_up_glue 0
set_constant -type port i:/WORK/${design_top}/noc_up_wrap_inst1/reg_isolation_ulk0_scp_glue 0

###############################################################################################################################
###############################################  gp3_mid  ######################################################################
###############################################################################################################################


} elseif { $design_top == "mid_top_wrap" } {

set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc0_ppu_isolation_gpc0_l1_to_matrix_to_sub1 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc1_ppu_isolation_gpc1_l1_to_matrix_to_sub1 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc2_ppu_isolation_gpc2_l1_to_matrix_to_sub1 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc3_ppu_isolation_gpc3_l1_to_matrix_to_sub1 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/gpc0_xbar_l1_wrap/gpc0_ppu_isolation_gpc0_l1_to_matrix 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/gpc1_xbar_l1_wrap/gpc1_ppu_isolation_gpc1_l1_to_matrix 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/gpc2_xbar_l1_wrap/gpc2_ppu_isolation_gpc2_l1_to_matrix 0
set_constant -type port r:/WORK/${design_top}/u_noc_middle_wrap/gpc3_xbar_l1_wrap/gpc3_ppu_isolation_gpc3_l1_to_matrix 0

set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc0_ppu_isolation_gpc0_l1_to_matrix_to_sub1 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc1_ppu_isolation_gpc1_l1_to_matrix_to_sub1 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc2_ppu_isolation_gpc2_l1_to_matrix_to_sub1 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/noc_middle_matrix_sub1_wrap/gpc3_ppu_isolation_gpc3_l1_to_matrix_to_sub1 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/gpc0_xbar_l1_wrap/gpc0_ppu_isolation_gpc0_l1_to_matrix 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/gpc1_xbar_l1_wrap/gpc1_ppu_isolation_gpc1_l1_to_matrix 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/gpc2_xbar_l1_wrap/gpc2_ppu_isolation_gpc2_l1_to_matrix 0
set_constant -type port i:/WORK/${design_top}/u_noc_middle_wrap/gpc3_xbar_l1_wrap/gpc3_ppu_isolation_gpc3_l1_to_matrix 0


###############################################################################################################################
###############################################  gp3_btm  ######################################################################
###############################################################################################################################

} elseif { $design_top == "gp3a_me_top_wrap" } {


} elseif { $design_top == "inno_112g_eth_rdma_top" } {

} elseif { $design_top == "P5_inno_pcie_top_wrapper" } {


} elseif { ($design_top == "bottom_top_wrap")  } {
set_constant -type port r:/WORK/${design_top}/rdma_sub_btm_inst/reg_isolation_rdma_sub_btm_glue 0
#set_constant -type port r:/WORK/${design_top}/noc_bottom_wrap_inst0/ctrl_pm_pcie5_btm_off 0
set_constant -type port r:/WORK/${design_top}/noc_bottom_wrap_inst0/pcie5_dp_wrap_inst/pcie_ppu_isolation 0

set_constant -type port i:/WORK/${design_top}/rdma_sub_btm_inst/reg_isolation_rdma_sub_btm_glue 0
#set_constant -type port i:/WORK/${design_top}/noc_bottom_wrap_inst0/ctrl_pm_pcie5_btm_off 0
set_constant -type port i:/WORK/${design_top}/noc_bottom_wrap_inst0/pcie5_dp_wrap_inst/pcie_ppu_isolation 0
###############################################################################################################################
###############################################  gp3_left  ######################################################################
###############################################################################################################################

} elseif { $design_top == "inno_ddr_ctrl_phy_ew_top_ip" } {

} elseif { $design_top == "inno_ddr_ctrl_phy_ns_top_ip" } {


} elseif { ($design_top == "left_top")  } {


###############################################################################################################################
###############################################  gp3_right  ######################################################################
###############################################################################################################################
} elseif { $design_top == "right_top" } {





}
