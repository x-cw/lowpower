
if { $design_top == "GP3A_TOP" } {

source ../script/waive_list_rtl/$design_top


} elseif { ($design_top == "scp_top_wrap")  } {


} elseif { ($design_top == "inno_ualink_ip_top")  } {


} elseif {  ($design_top == "inno_only_ualink_ip_top") } {



} elseif { ($design_top == "up_top_wrap")  } {

   #UP


} elseif { $design_top == "mid_top_wrap" } {

   # mid


} elseif { ($design_top == "gp3a_me_top_wrap")  } {

   #BTM

} elseif {  ($design_top == "bottom_top_wrap") } {

   #BTM
} elseif {  ($design_top == "inno_112g_eth_rdma_top") } {

   #BTM

} elseif {  ($design_top == "P5_inno_pcie_top_wrapper") } {

   #BTM


} elseif { ($design_top == "inno_ddr_ctrl_phy_ew_top_ip")  } {


} elseif {  ($design_top == "inno_ddr_ctrl_phy_ns_top_ip") } {


} elseif {  ($design_top == "left_top") } {

   #LEFT

} elseif { $design_top == "right_top" } {


} 
