sh date '+DATE: %m/%d/%y%nTIME: %H:%M'
# GLOBAL VARIABLES
set REPORTS_DIR ../reports/pg_check
#setenv UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
#set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
set GP3_RTL /home/Storage_Plugins/Frontend/xucw/GP3/GPUHW/code/soc/design/src

# read_verilog command option
set READ_OPT "-netlist"
set tool "vc-lp"
set do_restart_session "false"

set design_top  $DESIGN_TOP


# REPORTS
if !{[file exists $REPORTS_DIR]} {
  sh mkdir -p $REPORTS_DIR
}


# SETUP
source ../script/synopsys_vcst.setup

# HETEROGENEOUS FANOUT
set upf_hetero_fanout_isolation true


if { $do_restart_session == "false" } {

echo "info: start read netlist"
#---------------------------------------------------------------------
#                  read lib/db
#---------------------------------------------------------------------

source ../script/read_pg_db.tcl


#---------------------------------------------------------------------
#                  auto_bbox
#---------------------------------------------------------------------



#  Target technology logical libraries (used by DC, DCCNT)


#enable_rca_cluster -app lp 

set_app_var enable_auto_bbox_identification true
#if {[file exists ../run/out_bbox.tcl]}  {
#   source ../run/out_bbox.tcl
#}
#---------------------------------------------------------------------
#                  read netlist
#---------------------------------------------------------------------
# READ RTL

#noc
#read_verilog -netlist ../result/${design_top}_dc_iso.v
source ../script/read_pg_netlist.tcl

#---------------------------------------------------------------------
#                  link
#---------------------------------------------------------------------


current_design ${design_top}
link
#elaborate ${design_top} -j 16 -vcs "+warn=noSM_DNS +lint=TFIPC-L"



#enable_lp_dump_debug_reports  -dump_decompile_upf -dump_crossover -dump_crossover_through_info 5


checkpoint_session -session Session_Read_Pg_Design
#restart_session -session SessionReadDesign
} elseif { $do_restart_session == "true" } {
echo "info: restart session"
restart_session -session Session_Read_Pg_Design -force 
}
#execute_rootcause_analysis -app lp




#---------------------------------------------------------------------
#                  read upf
#---------------------------------------------------------------------


# LOAD UPF, use report_read to simplify messaging
if { (${design_top} == "mid_top_wrap") || (${design_top} == "up_top_wrap") || (${design_top} == "bottom_top_wrap") || (${design_top} == "left_top") || (${design_top} == "right_top") || (${design_top} == "GP3A_TOP")   } {

    #load_upf ../../flatten_upf/${design_top}_flatten_forBE.upf -j 16
    load_upf ../../flatten_upf_for_check/${design_top}_flatten_forBE.upf -j 16
 } else {
 
    #load_upf ../result/${design_top}_forBE.upf -j 16
    load_upf ../../flatten_upf_for_check/${design_top}_forBE.upf -j 16
 
 }

#load_upf ../upf/${design_top}.upf -supplemental ../../supp_upf/${design_top}_supplement.upf -strict_check false -j 16
#---------------------------------------------------------------------
#                  identify_lp_blackboxes
#---------------------------------------------------------------------

identify_lp_blackboxes -file ../run/out_bbox.tcl

#generate_crossovers -j 16

#enable_lp_dump_debug_reports   -dump_crossover_through_info 5



#---------------------------------------------------------------------
#                  configure_lp
#---------------------------------------------------------------------


report_violation

#waive list/disable_rule
#configure_lp_tag -tag ISO_INSTMISSING_NOISO -disable
#configure_lp_tag -tag ISO_DATA_CONSTANT -disable
#configure_lp_tag -tag LS_INPUT_TIEHI -disable
#configure_lp_tag -tag LS_INPUT_TIELO -disable

#---------------------------------------------------------------------
#                  waive
#---------------------------------------------------------------------
set default_waiver_file   ../script/waive_list_pg/${design_top}_awl.tcl
source ../script/waive_list_pg/${design_top}_awl.tcl
#---------------------------------------------------------------------
#                  report
#---------------------------------------------------------------------


# CHECK/REPORT
redirect -file $REPORTS_DIR/netlist_check_lp_upf.${design_top}.upf.rpt {check_lp -stage upf -j 16}
# CHECK/REPORT
redirect -file $REPORTS_DIR/netlist_check_lp_design.${design_top}.upf.rpt {check_lp -stage design -j 16}
# CHECK/REPORT
redirect -file $REPORTS_DIR/netlist_check_lp_pg.${design_top}.upf.rpt {check_lp -stage pg -j 16}


redirect -file $REPORTS_DIR/netlist_report_lp_pg.${design_top}.list.rpt {report_lp -list}


#execute_rootcause_analysis -app lp
checkpoint_session -session  Session_Pg_Check
#save_session -session Session_Pg_Check
sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

start_gui

#exit
