sh date '+DATE: %m/%d/%y%nTIME: %H:%M'
set begin_date [sh date +%y%m%d_%H]

echo "start_run_time: $begin_date"
#setenv UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
#set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl

set GP3_RTL /home/Storage_Plugins/Frontend/xucw/GP3/GPUHW/code/soc/design/src

set design_top $DESIGN_TOP

# only use in formality
set READ_OPT "-netlist"
set tool "DC"


set do_read_ddc "false"


set_host_options -max_cores 16
report_host_options



#---------------------------------------------------------------------
#                  read lib/db
#---------------------------------------------------------------------
source ../script/read_lp_db.tcl

#---------------------------------------------------------------------
#                  read dft netlist
#---------------------------------------------------------------------
if { $do_read_ddc == "false" } {


source ../script/read_lp_netlist.tcl


#---------------------------------------------------------------------
#                  link
#---------------------------------------------------------------------
current_design ${design_top}
link

#return
write -hierarchy -format ddc     -output "../result/${design_top}_merge_upf_link.ddc"


} elseif { $do_read_ddc == "true" } {
read_ddc ../result/${design_top}_merge_upf_link.ddc

}
#return
#---------------------------------------------------------------------
#                  read upf
#---------------------------------------------------------------------


## To use the golden UPF flow,
#set_app_var enable_golden_upf true

set upf_allow_refer_before_define true

###load upf
if { $design_top == "GP3A_TOP" } {
    load_upf ../upf/GP3A_TOP.upf      
    load_upf ../../flatten_upf_for_check/up_top_wrap_flatten_forBE.upf      -scope {u_up_top_wrap}
    load_upf ../../flatten_upf_for_check/bottom_top_wrap_flatten_forBE.upf  -scope {u_bottom_top_wrap}
    load_upf ../../flatten_upf_for_check/mid_top_wrap_flatten_forBE.upf     -scope {u_mid_top_wrap}
    load_upf ../../flatten_upf_for_check/left_top_flatten_forBE.upf         -scope {u_left_top}
    load_upf ../../flatten_upf_for_check/right_top_flatten_forBE.upf        -scope {u_right_top}


} elseif { $design_top == "up_top_wrap" } {
    load_upf ../../dc_output_upf/${design_top}_forBE.upf 
    load_upf ../../dc_output_upf/scp_top_wrap_forBE.upf -scope {scp_top_wrap_inst}
    load_upf ../../dc_output_upf/inno_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst0}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst1}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst2}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst3}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst4}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst5}
    load_upf ../../dc_output_upf/inno_only_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst6}
    load_upf ../../dc_output_upf/inno_ualink_ip_top_forBE.upf -scope {inno_ualink_ip_top_inst7}

      
} elseif { $design_top == "bottom_top_wrap" } {
    load_upf ../../dc_output_upf/${design_top}_forBE.upf
    load_upf ../../dc_output_upf/gp3a_me_top_wrap_forBE.upf -scope {gp3a_vcodec_top_wrap_inst0}
    load_upf ../../dc_output_upf/gp3a_me_top_wrap_forBE.upf -scope {gp3a_vcodec_top_wrap_inst1}
    load_upf ../../dc_output_upf/inno_112g_eth_rdma_top_forBE.upf -scope {inno_112g_eth_rdma_top_inst}
    load_upf ../../dc_output_upf/P5_inno_pcie_top_wrapper_forBE.upf -scope {P5_inno_pcie_top_wrapper_btm_inst}

} elseif { $design_top == "left_top" } {
    load_upf ../../dc_output_upf/${design_top}_forBE.upf
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr0/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr1/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr2/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr3/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ns_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr4/u_inno_ddr_ctrl_phy_ns_top}


} elseif { $design_top == "right_top" } {

    load_upf ../../dc_output_upf/${design_top}_forBE.upf
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr5/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr6/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr7/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ew_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr8/u_inno_ddr_ctrl_phy_ew_top}
    load_upf ../../dc_output_upf/inno_ddr_ctrl_phy_ns_top_ip_forBE.upf -scope {u_inno_gddrn_ctrl_phy_top_ddr9/u_inno_ddr_ctrl_phy_ns_top}

} else {
    load_upf ../../dc_output_upf/${design_top}_forBE.upf
}

# must use dc_2019
# propagate all block upf constraints to top upf.
propagate_constraints -power_supply_data
#---------------------------------------------------------------------
#                  set operating_conditions
#---------------------------------------------------------------------

### operate conditions
#set_operating_conditions SSPG0P675VN40C 


#set_operating_conditions -max ssgnp0p72vm40c -min ffgnp0p88v125c -analysis_type bc_wc
source ../script/set_voltage.tcl




# Controls  HTML reporting of unmapped power management cells
set upf_generate_pm_cell_html true

####5. insert iso/ls cells
set_message_info -id UPF-710 -limit 1000




#---------------------------------------------------------------------
#                  WRITE DB
#---------------------------------------------------------------------

set mv_output_upf_line_width 120
set mv_output_upf_line_indent 4
if { $design_top == "GP3A_TOP" } {

    # used  only in the UPF-prime mode
    save_upf -full_upf ../../flatten_upf_for_check/${design_top}_flatten_forBE.upf 
    
    # innovus is not support "-supply"
    sh sed -i "s/add_power_state\s*-supply/add_power_state /"  ../../flatten_upf_for_check/${design_top}_flatten_forBE.upf

} else {
    # used  only in the UPF-prime mode
    save_upf -full_upf ../../flatten_upf/${design_top}_flatten_forBE.upf 
    
    # innovus is not support "-supply"
    sh sed -i "s/add_power_state\s*-supply/add_power_state /"  ../../flatten_upf/${design_top}_flatten_forBE.upf


}

# used only in the golden UPF mode
#save_upf -supplemental ../result/${design_top}_supplement.upf -include_supply_exceptions


#write -hierarchy -format ddc     -output "../result/${design_top}_iso.ddc"


#---------------------------------------------------------------------
#                 generate report
#---------------------------------------------------------------------

#generate reports
#associate_mv_cells
if !{[file exists ../reports/merge_upf]} {
sh mkdir ../reports/merge_upf
}
check_mv_design -verbose > ../reports/merge_upf/${design_top}_dc.check_mv_design
report_isolation_cell -nosplit -domain [get_power_domains] -verbose > ../reports/merge_upf/${design_top}.isolation_cell
report_level_shifter  -nosplit -domain [get_power_domains] -verbose > ../reports/merge_upf/${design_top}.level_shift_cell
report_power_switch -verbose > ../reports/merge_upf/${design_top}.power_switch_cell
report_area                 > ../reports/merge_upf/${design_top}.lp_area
report_cell [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical] -nosplit > ../reports/merge_upf/${design_top}.lp_cell_area
