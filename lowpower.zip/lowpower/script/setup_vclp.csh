#! /bin/csh

if (! -e vclp_rtl_sess) then
  mkdir vclp_rtl_sess
endif

if (! -e vclp_netlist_sess) then
  mkdir vclp_netlist_sess
endif

if (! -e vclp_pg_sess) then
  mkdir vclp_pg_sess
endif

if (! -e logs) then
  mkdir ../logs
endif

if (! -e reports) then
  mkdir ../reports
endif


if (! -e result) then
  mkdir ../result
endif

if (! -e work) then
  mkdir ../work
endif
