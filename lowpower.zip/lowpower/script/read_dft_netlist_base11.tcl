################################################################################################################################



###############################################################################################################################
###############################################  gp3_top  ######################################################################
###############################################################################################################################
if {$design_top == "GP3A_TOP"} {
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/GP3A_TOP.dft.r29653.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/tvs_pad_samsung4lpp_r29653.v  
    ###############################################  netlist  #####################################################################
    # up
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ualink_ip_top.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/scp_top_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_up_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/up_top_wrap.dft.default.vg
    ## mid
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc0_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc1_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc2_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc3_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/l2g_0_1_xbar_l2_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/l2g_2_3_xbar_l2_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/l2g_4_5_xbar_l2_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/l2g_6_7_xbar_l2_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_middle_matrix_sub0_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_middle_matrix_sub1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_middle_matrix_sub2_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/mid_top_wrap.dft.default.vg
    # btm
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gp3a_me_top_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_bottom_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/bottom_top_wrap.dft.default.vg
    
    # right 
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/right_top.dft.default.vg
    # left 
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/left_top.dft.default.vg
    # other
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_cp_ce_wrapper.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc_wrap_top.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_l2_bank_group_wrap_a.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_l2_bank_group_wrap_b.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_cu_wrapper.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_eu_wrapper.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_l2_bank.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gc_spc_top.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip_top.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ew.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ns.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ew.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ns.dft.default.vg
    
    
    ###############################################  empty netlist  #####################################################################
    # up
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ualink_ip_top.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/scp_top_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_up_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/up_top_wrap.v
    ## mid
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc0_xbar_l1_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc1_xbar_l1_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc2_xbar_l1_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc3_xbar_l1_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_0_1_xbar_l2_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_2_3_xbar_l2_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_4_5_xbar_l2_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_6_7_xbar_l2_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_middle_matrix_sub0_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_middle_matrix_sub1_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_middle_matrix_sub2_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/mid_top_wrap.v
    ## btm
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gp3a_me_top_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_bottom_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/bottom_top_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_pcie_top_wrapper.v
    #
    ## right 
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/right_top.v
    ## left 
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/left_top.v
    ## other
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_cp_ce_wrapper.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc_wrap_top.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_l2_bank_group_wrap_a.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_l2_bank_group_wrap_b.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_cu_wrapper.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_eu_wrapper.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_l2_bank.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_spc_top.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip_top.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ns.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ns.v




###############################################################################################################################
###############################################  gp3_up  ######################################################################
###############################################################################################################################


} elseif { $design_top == "inno_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ualink_ip_top.dft.default.vg


} elseif { $design_top == "scp_top_wrap" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/scp_top_wrap.dft.default.vg

} elseif { $design_top == "inno_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ualink_ip_top.dft.default.vg


} elseif { $design_top == "up_top_wrap" } {

    ###############################################  netlist  #####################################################################
    # up
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ualink_ip_top.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/scp_top_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_up_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/up_top_wrap.dft.default.vg

    ###############################################  empty netlist  #####################################################################
    # up
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ualink_ip_top.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/scp_top_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_up_wrap.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/up_top_wrap.v




###############################################################################################################################
###############################################  gp3_mid  ######################################################################
###############################################################################################################################


} elseif { $design_top == "mid_top_wrap" } {
    ###############################################  netlist  #####################################################################
    ## mid
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc0_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc1_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc2_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gpc3_xbar_l1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_middle_matrix_sub1_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/mid_top_wrap.dft.default.vg

    
    
    ###############################################  empty netlist  #####################################################################
    ## mid
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_0_1_xbar_l2_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_2_3_xbar_l2_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_4_5_xbar_l2_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/l2g_6_7_xbar_l2_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_middle_matrix_sub0_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/noc_middle_matrix_sub2_wrap.v
    ## other
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gpc_wrap_top.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_l2_bank_group_wrap_a.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_l2_bank_group_wrap_b.v





###############################################################################################################################
###############################################  gp3_btm  ######################################################################
###############################################################################################################################


} elseif { $design_top == "gp3a_me_top_wrap" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gp3a_me_top_wrap.dft.default.vg


} elseif { $design_top == "bottom_top_wrap" } {
    ###############################################  netlist  #####################################################################
    # btm
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/gp3a_me_top_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/noc_bottom_wrap.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/bottom_top_wrap.dft.default.vg


    
    ###############################################  empty netlist  #####################################################################
    ## btm
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gc_cp_ce_wrapper.v    
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/gp3a_me_top_wrap.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_pcie_top_wrapper.v





###############################################################################################################################
###############################################  gp3_left  ######################################################################
###############################################################################################################################
} elseif { $design_top == "inno_ddr_ctrl_phy_ew_top_ip" } {
    ###############################################  netlist  #####################################################################


    # ddr
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ew.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ns.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ew.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_ns.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip_top.dft.default.vg

    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip_top.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ns.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ns.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_ns.v


} elseif { $design_top == "inno_ddr_ctrl_phy_ns_top_ip" } {
    ###############################################  netlist  #####################################################################
    # ddr
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ew.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_dig_ns.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_digtop_ns.dft.default.vg
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_ew.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_lpd_phy_ns.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip.dft.default.vg
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/inno_combo_memory_ctrl_ip_top.dft.default.vg

    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_combo_memory_ctrl_ip_top.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_dig_ns.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_digtop_ns.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_ew.v
    #read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_lpd_phy_ns.v




} elseif { $design_top == "left_top" } {
    ###############################################  netlist  #####################################################################

    # left 
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/left_top.dft.default.vg
    
    ###############################################  empty netlist  #####################################################################
    ## other
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.v






###############################################################################################################################
###############################################  gp3_right  ######################################################################
###############################################################################################################################
} elseif { $design_top == "right_top" } {
    ###############################################  netlist  #####################################################################

    
    # right 
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base11/right_top.dft.default.vg

    
    
    ###############################################  empty netlist  #####################################################################
    ## other
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ew_top_ip.v
    read_verilog -netlist $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base11/inno_ddr_ctrl_phy_ns_top_ip.v







}
