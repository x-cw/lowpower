proc check_gtech {file} {
  #set file [lindex $argv 0]
  
  # grep 查找 GETCH
  set ret [catch {exec grep "GTECH" $file} result]
  
  # grep找到时返回0，未找到返回1
  if {$ret == 0} {
      echo "ERROR: Found GTECH in $file"
  }
  
  if {$ret == 1 } {
    echo "Information: Not found GTECH in $file"
  }

}

set file_list [sh ls ../result/*.v]


foreach file $file_list {
  echo "check file : $file"
  check_gtech $file
}
