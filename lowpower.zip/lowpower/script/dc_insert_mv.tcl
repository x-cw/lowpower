sh date '+DATE: %m/%d/%y%nTIME: %H:%M'
set begin_date [sh date +%y%m%d_%H]

echo "start_run_time: $begin_date"
#setenv UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl
#set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test/rtl

set GP3_RTL /home/Storage_Plugins/Frontend/xucw/GP3/GPUHW/code/soc/design/src

# only use in formality
set READ_OPT "-netlist"
set tool "DC"

set design_top $DESIGN_TOP

## read link ddc: true or false
set do_read_ddc "false"

set_svf "../result/$design_top.svf"

if { $design_top == "up_top_wrap" } {
    set sub_designs " \
    noc_up_wrap_sub0 \
    noc_up_wrap_sub1 \
    " 
    set sub_empty_designs " \
    scp_top_wrap \
    inno_ualink_ip_top_lpmn_0 \
    inno_ualink_ip_top_lpmn_1 \
    inno_ualink_ip_top_lpmn_2 \
    inno_ualink_ip_top_lpmn_3 \
    inno_ualink_ip_top_lpmn_4 \
    inno_ualink_ip_top_lpmn_5 \
    inno_ualink_ip_top_lpmn_6 \
    inno_ualink_ip_top_lpmn_7 \
    "
} elseif { $design_top == "mid_top_wrap" } {
    set sub_designs " \
    noc_middle_matrix_sub1_wrap \
    gpc0_xbar_l1_wrap \
    gpc1_xbar_l1_wrap \
    gpc2_xbar_l1_wrap \
    gpc3_xbar_l1_wrap \
    "
    set sub_empty_designs " \
    gpc_wrap_top_lpmn_0 \
    gpc_wrap_top_lpmn_1 \
    gpc_wrap_top_lpmn_2 \
    gpc_wrap_top_lpmn_3 \
    "     
      
} elseif { $design_top == "bottom_top_wrap" } {
    set sub_designs " \
    noc_bottom_wrap \
    rdma_sub_btm \
    "
    set sub_empty_designs " \
    gp3a_me_top_wrap_lpmn_0 \
    gp3a_me_top_wrap_lpmn_1 \
    inno_112g_eth_rdma_top \
    P5_inno_pcie_top_wrapper \
    "      


} elseif { $design_top == "left_top" } {
    set sub_designs " \
    left_top_noc_left_wrapper_0_0 \
    "
    set sub_empty_designs " \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_0 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_1 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_2 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_3 \
    inno_ddr_ctrl_phy_ns_top_ip \
    "     

} elseif { $design_top == "right_top" } {
    set sub_designs " \
    right_top_noc_right_wrapper_0_0 \
    "
    set sub_empty_designs " \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_0 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_1 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_2 \
    inno_ddr_ctrl_phy_ew_top_ip_lpmn_3 \
    inno_ddr_ctrl_phy_ns_top_ip \
    " 
} else {
    set sub_designs ""
    set sub_empty_designs ""
}




set_host_options -max_cores 16
report_host_options

#---------------------------------------------------------------------
#                  read lib/db
#---------------------------------------------------------------------
source ../script/read_dft_db.tcl


#read_ddc ../result/${design_top}_iso.ddc

#---------------------------------------------------------------------
#                  read dft netlist
#---------------------------------------------------------------------
if { $do_read_ddc == "false" } {
echo "info: start read netlist"
#source  ../${design_top}_netlist.f
#read_verilog -netlist ../result/top_samsung8lpp.v
#read_verilog -netlist ../result/top_samsung4lpp.v

source ../script/read_dft_netlist.tcl

#write -hierarchy -format ddc     -output "./result/${design_top}_db.ddc"

#---------------------------------------------------------------------
#                  link
#---------------------------------------------------------------------
current_design ${design_top}
link

#return

write -hierarchy -format ddc     -output "../result/${design_top}_dc_insert_link.ddc"
} elseif { $do_read_ddc == "true" } {
echo "info: start read ddc"
read_ddc ../result/${design_top}_dc_insert_link.ddc
}

remove_sdc
#---------------------------------------------------------------------
#                  read upf
#---------------------------------------------------------------------


## To use the golden UPF flow,
#set_app_var enable_golden_upf true

###load upf
load_upf ../upf/${design_top}.upf

#---------------------------------------------------------------------
#                  set operating_conditions
#---------------------------------------------------------------------

### operate conditions
#set_operating_conditions SSPG0P675VN40C 
#set_operating_conditions  sspg_0p7650v_m40c


#set_operating_conditions -max ssgnp0p72vm40c -min ffgnp0p88v125c -analysis_type bc_wc
source ../script/set_voltage.tcl




# Controls  HTML reporting of unmapped power management cells
set upf_generate_pm_cell_html true

####5. insert iso/ls cells
set_message_info -id UPF-710 -limit 1000

##---------------------------------------------------------------------
##                  characterize to constraint to sub-module inst
##---------------------------------------------------------------------
#
#if { (${design_top} == "up_top_wrap") || (${design_top} == "bottom_top_wrap")}  {
#  set begin_date1 [sh date +%y%m%d_%H:%M:%S]
#    foreach sub_design $sub_designs {
#        if {[get_designs $sub_design ] != ""} {
#          set sub_diesign_inst [get_cells * -filter "ref_name == $sub_design" -hierarchical] 
#          characterize  $sub_diesign_inst  
#          #characterize  $sub_diesign_inst -verbose > ../reports/${sub_design}_characterize.log
#      }
#    }
#  set end_date1 [sh date +%y%m%d_%H:%M:%S]
#  echo "start_run_characterize_time: $begin_date1"
#  echo "end_run_characterize_time: $end_date1"
#    
#}
#---------------------------------------------------------------------
#                  uniquify multi-instance
#---------------------------------------------------------------------
#add uniquify for fixing DC error

# other
set uniquify_naming_style "%s_lpmn_%d"
uniquify 

#---------------------------------------------------------------------
#                  dont touch
#---------------------------------------------------------------------

#set dont touch because the new added buff will disappear
if { $sub_designs  == ""} {
     set_dont_touch [get_cells -hierarchical -filter "full_name =~ *"]
} else {

   foreach sub_design $sub_designs {
       if {[get_designs $sub_design ] != ""} {
         set sub_diesign_hier [get_object_name  [get_cells * -filter "ref_name == $sub_design" -hierarchical] ]
         set sub_diesign_hier_i "$sub_diesign_hier/*"
         set_dont_touch [get_cells -hierarchical -filter "full_name =~ \"$sub_diesign_hier_i\""]
     }
   }
}


#  The dont_use/dont_touch attr of lp cells in s4 lib is true.
set_attr [get_lib_cells */*] dont_use false
set_attr [get_lib_cells */*] dont_touch false



#---------------------------------------------------------------------
#                  insert lp cells
#---------------------------------------------------------------------

insert_mv_cells -verbose

#return

#---------------------------------------------------------------------
#                  check insert cell num
#---------------------------------------------------------------------

source ../script/insert_lp_cell_num_check_v2.tcl


#---------------------------------------------------------------------
#                  characterize to constraint to sub-module inst
#---------------------------------------------------------------------

if { (${design_top} == "up_top_wrap") || (${design_top} == "bottom_top_wrap")}  {
  set begin_date1 [sh date +%y%m%d_%H:%M:%S]
    foreach sub_design $sub_designs {
        if {[get_designs $sub_design ] != ""} {
          set sub_diesign_inst [get_cells * -filter "ref_name == $sub_design" -hierarchical] 
          characterize  $sub_diesign_inst  
          #characterize  $sub_diesign_inst -verbose > ../reports/${sub_design}_characterize.log
      }
    }
  set end_date1 [sh date +%y%m%d_%H:%M:%S]
  echo "start_run_characterize_time: $begin_date1"
  echo "end_run_characterize_time: $end_date1"
    
}
#---------------------------------------------------------------------
#                 generate report
#---------------------------------------------------------------------

#generate reports
#associate_mv_cells
check_mv_design -verbose > ../reports/${design_top}_dc.check_mv_design
report_isolation_cell -nosplit -domain [get_power_domains] -verbose > ../reports/${design_top}.isolation_cell
report_level_shifter  -nosplit -domain [get_power_domains] -verbose > ../reports/${design_top}.level_shift_cell
report_power_switch -verbose > ../reports/${design_top}.power_switch_cell
report_area                 > ../reports/${design_top}.lp_area
report_cell [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical] -nosplit > ../reports/${design_top}.lp_cell_area



#---------------------------------------------------------------------
#                  WRITE DB
#---------------------------------------------------------------------
change_names -rules verilog -hier 

set_svf -off


set mv_output_upf_line_width 120
set mv_output_upf_line_indent 4
# used  only in the UPF-prime mode
save_upf -full_upf ../result/${design_top}_forBE.upf 

# innovus is not support "-supply"
#sh sed -i "s/add_power_state\s*-supply/add_power_state /"  ../result/${design_top}_forBE.upf

# used only in the golden UPF mode
#save_upf -supplemental ../result/${design_top}_supplement.upf -include_supply_exceptions





write -hierarchy -format ddc     -output "../result/${design_top}_iso.ddc"


if { (${design_top} == "left_top") || (${design_top} == "right_top")} {
  remove_design [get_designs $sub_empty_designs]
  current_design ${design_top}
  write -hierarchy -format verilog -output "../result/${design_top}_dc_iso.v"
  sh sed -i "s/_lpmn_\[0-9\] / /" ../result/${design_top}_dc_iso.v
  current_design ${design_top}
  remove_design -all
  read_ddc ../result/${design_top}_iso.ddc

} elseif { (${design_top} == "inno_ddr_ctrl_phy_ew_top_ip")} {

  remove_design [get_designs "inno_combo_memory_ctrl_ip_top_lpmn_0 inno_combo_memory_ctrl_ip_top_lpmn_1 inno_lpd_phy_ew_lpmn_0 inno_lpd_phy_ew_lpmn_1 inno_lpd_phy_ew_lpmn_2 inno_lpd_phy_ew_lpmn_3 "]
  current_design ${design_top}
  write -hierarchy -format verilog -output "../result/${design_top}_dc_iso.v"
  sh sed -i "s/_lpmn_\[0-9\] / /" ../result/${design_top}_dc_iso.v
  current_design ${design_top}
  remove_design -all
  read_ddc ../result/${design_top}_iso.ddc

} elseif { (${design_top} == "inno_ddr_ctrl_phy_ns_top_ip")} {

  remove_design [get_designs "inno_combo_memory_ctrl_ip_top_ns_lpmn_0 inno_combo_memory_ctrl_ip_top_ns_lpmn_1 inno_lpd_phy_ns_lpmn_0 inno_lpd_phy_ns_lpmn_1 inno_lpd_phy_ns_lpmn_2 inno_lpd_phy_ns_lpmn_3 "]
  current_design ${design_top}
  write -hierarchy -format verilog -output "../result/${design_top}_dc_iso.v"
  sh sed -i "s/_lpmn_\[0-9\] / /" ../result/${design_top}_dc_iso.v
  current_design ${design_top}
  remove_design -all
  read_ddc ../result/${design_top}_iso.ddc



} elseif { (${design_top} == "up_top_wrap") || (${design_top} == "bottom_top_wrap")|| (${design_top} == "mid_top_wrap")}  {


  write -hierarchy -format verilog -output "../result/${design_top}_dc_iso.v"
  foreach sub_design $sub_designs {
      if {[get_designs $sub_design ] != ""} {
        current_design ${sub_design}
        save_upf ../result/${sub_design}_forBE.upf
        write -hierarchy -format verilog -output "../result/${sub_design}_dc_iso.v"
    }
  }
  current_design ${design_top}


} else {

  write -hierarchy -format verilog -output "../result/${design_top}_dc_iso.v"

}

#---------------------------------------------------------------------
#                  check gtech cell
#---------------------------------------------------------------------

source ../script/insert_lp_cell_gtch_check.tcl


#---------------------------------------------------------------------
#                  save rpt
#---------------------------------------------------------------------
current_design ${design_top}



sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

set cur_date [sh date +%y%m%d_%H]
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/veri
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/rpt
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/upf
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/db
sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/svf

sh cp ../result/${design_top}.svf                        ../${design_top}_lowpower_netlist_${cur_date}/svf/   -rf
sh cp ../result/${design_top}_iso.ddc                    ../${design_top}_lowpower_netlist_${cur_date}/db/   -rf
sh cp ../reports/${design_top}_dc.check_mv_design        ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}.isolation_cell            ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}.level_shift_cell          ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}.power_switch_cell         ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}.lp_area                   ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}.lp_cell_area              ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf

sh cp ../result/${design_top}_forBE.upf                ../${design_top}_lowpower_netlist_${cur_date}/upf/   -rf
sh cp ../upf/${design_top}.upf                        ../${design_top}_lowpower_netlist_${cur_date}/upf/   -rf

sh cp ../reports/insert_lp_cell_num_check.rpt            ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf

sh cp ../result/${design_top}_forBE.upf                ../../dc_output_upf/   -rf


if {(${design_top} == "up_top_wrap") || (${design_top} == "bottom_top_wrap") || (${design_top} == "mid_top_wrap") } {
  foreach sub_design $sub_designs {
      if {[get_designs $sub_design ] != ""} {
        sh cp ../reports/${sub_design}_floating_signals_list.rpt            ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
        sh cp ../result/${sub_design}_forBE.upf                   ../${design_top}_lowpower_netlist_${cur_date}/upf/   -rf
        sh cp ../result/${sub_design}_dc_iso.v                   ../${design_top}_lowpower_netlist_${cur_date}/veri/   -rf
        sh cp ../result/${sub_design}_dc_iso.v                   ../../lp_netlist_base12/   -rf   
  
        sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/${sub_design}_lowpower_netlist_${cur_date}
        sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/${sub_design}_lowpower_netlist_${cur_date}/veri
        sh mkdir ../${design_top}_lowpower_netlist_${cur_date}/${sub_design}_lowpower_netlist_${cur_date}/upf
        sh cp ../result/${sub_design}_forBE.upf                   ../${design_top}_lowpower_netlist_${cur_date}/${sub_design}_lowpower_netlist_${cur_date}/upf/   -rf
        sh cp ../result/${sub_design}_dc_iso.v                    ../${design_top}_lowpower_netlist_${cur_date}/${sub_design}_lowpower_netlist_${cur_date}/veri/   -rf
    }
  }

} else {
  sh cp ../reports/${design_top}_floating_signals_list.rpt            ../${design_top}_lowpower_netlist_${cur_date}/rpt/   -rf
  sh cp ../result/${design_top}_dc_iso.v                   ../${design_top}_lowpower_netlist_${cur_date}/veri/   -rf
  sh cp ../result/${design_top}_dc_iso.v                   ../../lp_netlist_base12/   -rf
}

sh cp ../logs/${design_top}_dc_insert.log                ../${design_top}_lowpower_netlist_${cur_date}/       -rf
