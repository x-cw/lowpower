################################################################################################################################



###############################################################################################################################
###############################################  gp3_top  ######################################################################
###############################################################################################################################
if {$design_top == "GP3A_TOP"} {
    ###############################################  netlist  #####################################################################
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/GP3A_TOP.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/tvs_pad.output.pg.vg  

    # up
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ualink_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_only_ualink_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/scp_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_up_wrap_sub0.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_up_wrap_sub1.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/up_top_wrap.output.pg.vg

    ## mid
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc0_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc1_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc2_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc3_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub0_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub2_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/mid_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_0_1_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_2_3_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_4_5_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_6_7_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gpc_wrap_top.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gc_l2_bank_group_wrap_a.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gc_l2_bank_group_wrap_b.v

    # btm
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gp3a_me_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_bottom_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_112g_eth_rdma_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/bottom_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/P5_inno_pcie_top_wrapper.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/rdma_sub_btm.output.pg.vg

    
    # right 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/right_top.output.pg.vg

    # left 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/left_top.output.pg.vg

    #ddr
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v


    





###############################################################################################################################
###############################################  gp3_up  ######################################################################
###############################################################################################################################


} elseif { $design_top == "scp_top_wrap" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/scp_top_wrap.output.pg.vg
    #read_verilog ${READ_OPT}  /home/Project/2025/GP3A_S2412_SS4LPP/Backend/baiht/GP3A_TOP/STA/hier_data/low_power_data/scp_top_wrap/scp_top_wrap.output.pg.vg.gz
} elseif { $design_top == "inno_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ualink_ip_top.output.pg.vg

} elseif { $design_top == "inno_only_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_only_ualink_ip_top.output.pg.vg



} elseif { $design_top == "up_top_wrap" } {


    ###############################################  netlist  #####################################################################
    # up
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ualink_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_only_ualink_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/scp_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_up_wrap_sub0.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_up_wrap_sub1.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/up_top_wrap.output.pg.vg

    ###############################################  empty netlist  #####################################################################
    # up
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ualink_ip_top.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_only_ualink_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/scp_top_wrap.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/noc_up_wrap.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/up_top_wrap.v



###############################################################################################################################
###############################################  gp3_mid  ######################################################################
###############################################################################################################################


} elseif { $design_top == "mid_top_wrap" } {
    ###############################################  netlist  #####################################################################
    ## mid
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc_wrap_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc0_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc1_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc2_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gpc3_xbar_l1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub0_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub1_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_middle_matrix_sub2_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/mid_top_wrap.output.pg.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/l2g_4_5_xbar_l2_wrap.output.pg.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/l2g_6_7_xbar_l2_wrap.output.pg.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/l2g_0_1_xbar_l2_wrap.output.pg.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/l2g_2_3_xbar_l2_wrap.output.pg.vg
    
    ###############################################  empty netlist  #####################################################################
    ## mid
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_0_1_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_2_3_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_4_5_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/l2g_6_7_xbar_l2_wrap.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/noc_middle_matrix_sub0_wrap.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/noc_middle_matrix_sub2_wrap.v
    ## other
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gpc_wrap_top.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gc_l2_bank_group_wrap_a.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gc_l2_bank_group_wrap_b.v





###############################################################################################################################
###############################################  gp3_btm  ######################################################################
###############################################################################################################################


} elseif { $design_top == "gp3a_me_top_wrap" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gp3a_me_top_wrap.output.pg.vg



} elseif { $design_top == "inno_112g_eth_rdma_top" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_112g_eth_rdma_top.output.pg.vg

    ###############################################  empty netlist  #####################################################################
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_serdes_phy.v

} elseif { $design_top == "P5_inno_pcie_top_wrapper" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/P5_inno_pcie_top_wrapper.output.pg.vg

    ###############################################  empty netlist  #####################################################################
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_serdes_phy.v

} elseif { $design_top == "bottom_top_wrap" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/gp3a_me_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/noc_bottom_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_112g_eth_rdma_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/bottom_top_wrap.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/P5_inno_pcie_top_wrapper.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/rdma_sub_btm.output.pg.vg


    
    ###############################################  empty netlist  #####################################################################

    ## btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/gc_cp_ce_wrapper.v    
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/inno_pcie_top_wrapper.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/pg_empty_netlist_base12/P5_inno_pcie_top_wrapper.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_eth_rdma_top.v


    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/dc/noc_bottom_wrap_samsung4lpp_r32888_33219.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/dc/bottom_top_wrap_r32888.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/dc/empty_tie1/gc_cp_ce_wrapper.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/dc/empty_tie1/gp3a_me_top_wrap.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/dc/empty_tie1/inno_pcie_top_wrapper.v

###############################################################################################################################
###############################################  gp3_left  ######################################################################
###############################################################################################################################

} elseif { $design_top == "inno_ddr_ctrl_phy_ew_top_ip" } {
    ###############################################  netlist  #####################################################################


    # ddr
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v

    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ns.v


} elseif { $design_top == "inno_ddr_ctrl_phy_ns_top_ip" } {
    ###############################################  netlist  #####################################################################
    # ddr
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.output.pg.vg    
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v


    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ns.v





} elseif { ($design_top == "left_top")  } {
    ###############################################  netlist  #####################################################################

    # left 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/left_top.output.pg.vg
    #ddr
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v    
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ew.dft.default.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ns.dft.default.vg
    #
    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ns.v




###############################################################################################################################
###############################################  gp3_right  ######################################################################
###############################################################################################################################
} elseif { $design_top == "right_top" } {
    ###############################################  netlist  #####################################################################
    # right 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/right_top.output.pg.vg
    # other
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_ns.output.pg.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/pg_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.output.pg.vg    
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v    
 
    #
    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ns.v


}
