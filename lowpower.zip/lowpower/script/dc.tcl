sh date '+DATE: %m/%d/%y%nTIME: %H:%M'
setenv UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test_s4/rtl
set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/upf_test_s4/rtl
set design_top top

set TLIB_NAME samsung4lpp

set_svf "../result/$design_top.svf"


set_app_var search_path         [ list \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0170/LIBERTY/flk \
]

#../gftp/memory_db_20240509/pcie_db_20240506/db \

set_app_var target_library [ list \
ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p6750v_m40c.db_ccs_tn_lvf \
]

set lib_link_library [ list \
]


set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

set_app_var link_library "* $target_library $synthetic_library $lib_link_library"
#read_ddc ./result/${design_top}_iso.ddc


analyze -f sverilog -vcs "-f $UPF_TEST_RTL/top.f"

elaborate $design_top

write -hierarchy -format ddc     -output "../result/${design_top}_db.ddc"


set_target_library_subset -only_here  "ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf/*" -object_list [get_cells sub_b_inst]

#set_wire_load_model -name ZeroWireload

current_design ${design_top}
link



check_design        >   ../reports/${design_top}.unmapped.chk


# write unmapped ddc for recurrent synthesis
write -hierarchy -format ddc -output "../result/${design_top}.unmapped.ddc"


#source -e -v ../sdc/.sdc
create_clock -name "dbus_clk"             [get_ports "clk"]          -period 1

set_output_delay -clock "dbus_clk" 0.6 [get_ports "out_a out_b out_c"]
set_input_delay -clock "dbus_clk" 0.6 [get_ports "rstn ctrl_on in_a in_b in_c in_a_t in_b_t in_c_t"]


set_clock_uncertainty 0.200 [all_clocks]
set_max_fanout 32 [all_designs]

#set_dont_touch [get_cells -hierarchical -filter "full_name =~ sub_*_inst"]

report_timing -loop > ../reports/${design_top}.loop
check_timing > ../reports/${design_top}.unmapping.chk_timing

#3set_dont_touch [get_cells -hierarchical -filter "full_name =~ *ctrl_pm_sub_a_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_a_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_b_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_c_off*"]




uniquify


# add for multibit function
set_multibit_options -mode timing_driven

#clock gating exception
set_clock_gating_enable -exclude [all_inputs]


#---------------------------------------------------------------------
#                 COMPILE
#---------------------------------------------------------------------
# base option 
# compile_ultra -gate_clock -scan
set COMP_FLAG "-gate_clock"
#if { $USE_SCAN == 1 } {
    set COMP_FLAG [concat $COMP_FLAG "-scan"]
#}
set COMP_FLAG [concat $COMP_FLAG "-no_autoungroup"]

eval compile_ultra $COMP_FLAG




check_design                > ../reports/${design_top}_${TLIB_NAME}.chk
report_area                 > ../reports/${design_top}_${TLIB_NAME}.area
report_reference            > ../reports/${design_top}_${TLIB_NAME}.ref
report_reference -hier      > ../reports/${design_top}_${TLIB_NAME}.ref_hier
report_timing -path full -delay max -net -max_paths 100 -nworst 10 > ../reports/${design_top}_${TLIB_NAME}.tim

write -hierarchy -format verilog -output "../result/${design_top}_${TLIB_NAME}.v"
write -hierarchy -format ddc     -output "../result/${design_top}_${TLIB_NAME}.ddc"
write_sdc ../result/${design_top}_${TLIB_NAME}.sdc


set_svf -off

current_design ${design_top}

sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

set cur_date [sh date +%y%m%d_%H]
sh mkdir ../dc_netlist_${cur_date}
sh mkdir ../dc_netlist_${cur_date}/veri
sh mkdir ../dc_netlist_${cur_date}/rpt
sh mkdir ../dc_netlist_${cur_date}/sdc

sh cp ../result/${design_top}_${TLIB_NAME}.v                   ../dc_netlist_${cur_date}/veri/   -rf
sh cp ../result/${design_top}_${TLIB_NAME}.ddc                 ../dc_netlist_${cur_date}/veri/   -rf

sh cp ../reports/${design_top}_${TLIB_NAME}.chk                ../dc_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}_${TLIB_NAME}.area               ../dc_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}_${TLIB_NAME}.ref                ../dc_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}_${TLIB_NAME}.ref_hier           ../dc_netlist_${cur_date}/rpt/   -rf
sh cp ../reports/${design_top}_${TLIB_NAME}.tim                ../dc_netlist_${cur_date}/rpt/   -rf

sh cp ../result/${design_top}_${TLIB_NAME}.sdc                 ../dc_netlist_${cur_date}/veri/   -rf
