################################################################################################################################



###############################################################################################################################
###############################################  gp3_top  ######################################################################
###############################################################################################################################
if {$design_top == "GP3A_TOP"} {
    ###############################################  netlist  #####################################################################
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/GP3A_TOP.dft.r35046.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tvs_pad_samsung4lpp_r29653.v  
    # up
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ualink_ip_top_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_only_ualink_ip_top_dc_iso.v    
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco/ecoed_inno_ualink_ip_top_dc_iso.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/only_ualink_eco/ecoed_inno_only_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco_0730/0730ecoed_dft_ec_inno_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/20260730_only_ualink_ecoed_files/0730ecoed_0708_dft_ec_inno_only_ualink_ip_top_dc_iso.v
    
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/scp_top_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_up_wrap_sub1_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/up0_0630_EC/noc_up_wrap_sub0_DFTecoed_iso.v    
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/up_top_wrap.dft.r35050.vg
    ## mid
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/mid_top_wrap.dft.r34838.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260212_22/gpc3_xbar_l1_wrap_lowpower_netlist_260212_22/veri/gpc3_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260212_22/gpc1_xbar_l1_wrap_lowpower_netlist_260212_22/veri/gpc1_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260320_17/gpc2_xbar_l1_wrap_lowpower_netlist_260320_17/veri/gpc2_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260326_09/gpc0_xbar_l1_wrap_lowpower_netlist_260326_09/veri/gpc0_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260512_05/noc_middle_matrix_sub1_wrap_lowpower_netlist_260512_05/veri/noc_middle_matrix_sub1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_0_1_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_2_3_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_4_5_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_6_7_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/noc_middle_matrix_sub0_wrap.dft.r33219.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/noc_middle_matrix_sub2_wrap.dft.r33219.vg
    ## other
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gpc_wrap_top.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_l2_bank_group_wrap_a.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_l2_bank_group_wrap_b.v
    

    # btm
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/bottom_top_wrap.dft.r35142.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/rdma_sub_btm_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/bottom_top_wrap/bottom_top_wrap_lowpower_netlist_260603_20/rdma_sub_btm_lowpower_netlist_260603_20/veri/rdma_sub_btm_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_bottom_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gp3a_me_top_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/P5_inno_pcie_top_wrapper_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_112g_eth_rdma_top_dc_iso.v 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_cp_ce_wrapper.v    
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_pcie_top_wrapper.v      



    # right 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/right_top_dc_iso.v
    # left 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/left_top_dc_iso.v

    # ddr
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v 
 



###############################################################################################################################
###############################################  gp3_up  ######################################################################
###############################################################################################################################



} elseif { $design_top == "scp_top_wrap" } {

    ###############################################  netlist  #####################################################################
    # up
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/scp_top_wrap_dc_iso.v

} elseif { $design_top == "inno_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ualink_ip_top_dc_iso.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco/ecoed_inno_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco_0801/0801_ecoed_dft_ec_inno_ualink_ip_top_dc_iso.v


} elseif { $design_top == "inno_only_ualink_ip_top" } {

    ###############################################  netlist  #####################################################################
    # up
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_only_ualink_ip_top_dc_iso.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/only_ualink_eco/ecoed_inno_only_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/20260801_only_ualink_eco/0801ecoed_0708_dft_ec_inno_only_ualink_ip_top_dc_iso.v

} elseif { $design_top == "up_top_wrap" } {


    ###############################################  netlist  #####################################################################
    # up

    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_up_wrap_sub0_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_up_wrap_sub1_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/up_top_wrap.dft.r35050.vg

    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/up0_0630_EC/noc_up_wrap_sub0_DFTecoed_iso.v
    ###############################################  empty netlist  #####################################################################
    # up

    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/noc_up_wrap.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/up_top_wrap.v

    if {$tool == "FM"} {
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ualink_ip_top.v
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_only_ualink_ip_top.v
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/scp_top_wrap.v
    } else {
      #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ualink_ip_top_dc_iso.v
      #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_only_ualink_ip_top_dc_iso.v
      #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco/ecoed_inno_ualink_ip_top_dc_iso.v
      #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/only_ualink_eco/ecoed_inno_only_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/ualink_sue_combo_eco_0801/0801_ecoed_dft_ec_inno_ualink_ip_top_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/tar/20260801_only_ualink_eco/0801ecoed_0708_dft_ec_inno_only_ualink_ip_top_dc_iso.v

      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/scp_top_wrap_dc_iso.v
    }


###############################################################################################################################
###############################################  gp3_mid  ######################################################################
###############################################################################################################################


} elseif { $design_top == "mid_top_wrap" } {
    ###############################################  netlist  #####################################################################
    ## mid
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gpc0_xbar_l1_wrap_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gpc1_xbar_l1_wrap_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gpc2_xbar_l1_wrap_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gpc3_xbar_l1_wrap_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_middle_matrix_sub1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/mid_top_wrap.dft.r34838.vg

    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260212_22/gpc3_xbar_l1_wrap_lowpower_netlist_260212_22/veri/gpc3_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260212_22/gpc1_xbar_l1_wrap_lowpower_netlist_260212_22/veri/gpc1_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260320_17/gpc2_xbar_l1_wrap_lowpower_netlist_260320_17/veri/gpc2_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260326_09/gpc0_xbar_l1_wrap_lowpower_netlist_260326_09/veri/gpc0_xbar_l1_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/mid_top_wrap/mid_top_wrap_lowpower_netlist_260512_05/noc_middle_matrix_sub1_wrap_lowpower_netlist_260512_05/veri/noc_middle_matrix_sub1_wrap_dc_iso.v


     if {$tool == "FM"} {   
    ###############################################  empty netlist  #####################################################################
    ## mid
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/l2g_0_1_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/l2g_2_3_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/l2g_4_5_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/l2g_6_7_xbar_l2_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/noc_middle_matrix_sub0_wrap.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/noc_middle_matrix_sub2_wrap.v
    ## other
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/gpc_wrap_top.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/gc_l2_bank_group_wrap_a.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/gc_l2_bank_group_wrap_b.v
    } else {
    ## mid
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_0_1_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_2_3_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_4_5_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/l2g_6_7_xbar_l2_wrap.dft.r32888.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/noc_middle_matrix_sub0_wrap.dft.r33219.vg
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/noc_middle_matrix_sub2_wrap.dft.r33219.vg
    ###############################################  empty netlist  #####################################################################
    ## other
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gpc_wrap_top.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_l2_bank_group_wrap_a.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_l2_bank_group_wrap_b.v
    }


###############################################################################################################################
###############################################  gp3_btm  ######################################################################
###############################################################################################################################

} elseif { $design_top == "gp3a_me_top_wrap" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gp3a_me_top_wrap_dc_iso.v



} elseif { $design_top == "inno_112g_eth_rdma_top" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_112g_eth_rdma_top_dc_iso.v

    ###############################################  empty netlist  #####################################################################
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_serdes_phy.v

} elseif { $design_top == "P5_inno_pcie_top_wrapper" } {
    ###############################################  netlist  #####################################################################
    # btm
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/P5_inno_pcie_top_wrapper_dc_iso.v

    ###############################################  empty netlist  #####################################################################
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_serdes_phy.v

} elseif { ($design_top == "bottom_top_wrap")  } {
    ###############################################  netlist  #####################################################################
    # btm
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/rdma_sub_btm_dc_iso.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/noc_bottom_wrap_dc_iso.v
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/bottom_top_wrap.dft.r35142.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/bottom_top_wrap/bottom_top_wrap_lowpower_netlist_260603_20/rdma_sub_btm_lowpower_netlist_260603_20/veri/rdma_sub_btm_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/bottom_top_wrap/bottom_top_wrap_lowpower_netlist_260603_20/noc_bottom_wrap_lowpower_netlist_260603_20/veri/noc_bottom_wrap_dc_iso.v
    
    ###############################################  empty netlist  #####################################################################

    ## btm




    if {$tool == "FM"} {
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/gp3a_me_top_wrap.v
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/gc_cp_ce_wrapper.v    
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_pcie_top_wrapper.v      
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/P5_inno_pcie_top_wrapper.v
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_112g_eth_rdma_top.v      
    } else {
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/gp3a_me_top_wrap_dc_iso.v
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/gc_cp_ce_wrapper.v    
      read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_pcie_top_wrapper.v      
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/P5_inno_pcie_top_wrapper_dc_iso.v
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_112g_eth_rdma_top_dc_iso.v 
    }







###############################################################################################################################
###############################################  gp3_left  ######################################################################
###############################################################################################################################

} elseif { $design_top == "inno_ddr_ctrl_phy_ew_top_ip" } {
    ###############################################  netlist  #####################################################################


    # ddr
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip.dft.default.vg
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ew.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v

    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ns.v


} elseif { $design_top == "inno_ddr_ctrl_phy_ns_top_ip" } {
    ###############################################  netlist  #####################################################################
    # ddr
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip_dc_iso.v
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_ns.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.dft.default.vg    
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ns.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
    read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v


    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_lpd_phy_ns.v





} elseif { ($design_top == "left_top")  } {
    ###############################################  netlist  #####################################################################

    # left 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/left_top_dc_iso.v
 
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ew.dft.default.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ns.dft.default.vg
    #
    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ns.v

    
    if {$tool == "FM"} {
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    } else {
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip_dc_iso.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip_dc_iso.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v   
    }

###############################################################################################################################
###############################################  gp3_right  ######################################################################
###############################################################################################################################
} elseif { $design_top == "right_top" } {
    ###############################################  netlist  #####################################################################
    # right 
    read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/right_top_dc_iso.v
    # other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ew.dft.default.vg
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_dig_ns.dft.default.vg    
    #
    ###############################################  empty netlist  #####################################################################
    ## other
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_combo_memory_ctrl_ip_top.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_dig_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_digtop_ns.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ew.v
    #read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_empty_netlist_base12/inno_lpd_phy_ns.v

    if {$tool == "FM"} {
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip.v
      read_verilog ${READ_OPT}  $GP3_RTL/../../../flow_run/design/upf/dft_empty_tie1_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip.v
    } else {
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ew_top_ip_dc_iso.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/lp_netlist_base12/inno_ddr_ctrl_phy_ns_top_ip_dc_iso.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_combo_memory_ctrl_ip_top_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ew.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_digtop_ns.dft.default.vg
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ew.v
       read_verilog ${READ_OPT} $GP3_RTL/../../../flow_run/design/upf/dft_netlist_base12/inno_lpd_phy_ns.v   
    }




}
