## need change current_design
## input signal number
#set input_signal_num [sizeof_collection   [get_ports * -filter "pin_direction =~ in"]]
#echo "${curr_design} input signal num (A): $input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt
#
## echo floating_signals_list
#foreach_in_collection check_port [get_ports * -filter "port_direction =~ in"] {
#   set port_name [get_attribute [get_ports $check_port] full_name]
#   set count [sizeof_collection [all_fanout -flat -from [get_ports $port_name]]]
#   if {$count == 1} {
#        incr floating_signals_num
#        set floating_signals [get_attribute [get_ports $port_name] full_name]
#        echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
#   }
#}
#
## floating signlas number
#echo "${curr_design} is floating signlas num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
#
## should insert lp cell number
#set should_insert_lp_cell_num [expr $input_signal_num - $floating_signals_num]
#echo "${curr_design} should insert lp cells num (C=A-B): $should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt
#
##  inserted lp cell number
#set insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
#echo "${curr_design} is inserted lp cells num: $insert_lp_cell_num  \n\n\n\n" >> ../reports/insert_lp_cell_num_check.rpt

################################################################################################################################
current_design ${design_top}
echo "" > ../reports/insert_lp_cell_num_check.rpt


set top_should_insert_lp_cell_sum 0
set top_floating_signals_sum 0
set should_insert_lp_cell_sum 0
set floating_signals_sum 0
set insert_lp_cell_sum 0
set subtop_insert_lp_cell_sum 0
set subtop_insert_lp_cell_num 0
foreach sub_design $sub_designs {
    if {[get_designs $sub_design ] != ""} {
      set curr_design $sub_design
      set sub_input_cell [get_object_name  [get_cells * -filter "ref_name == $sub_design" -hierarchical] ]
      foreach sub_empty_design $sub_empty_designs {
        if {[get_designs $sub_empty_design ] != ""} {

          set sub_output_cell [get_cells * -filter "ref_name == $sub_empty_design" -hierarchical]
          set sub_input_cell_i "$sub_input_cell/*"

          # get sub_design pin signals to/from sub_empty_design 
          if { [regexp {gpc_wrap_top.*} $sub_empty_design]  || [regexp {.*noc_right_wrapper.*} $sub_empty_design]} {
            set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
            set input_net_signals [get_nets -of [get_pins -of $output_net_signals] -boundary_type lower]
            set input_signals [get_pins -of  $input_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]
          } elseif { [regexp {.*inno_ddr.*} $sub_empty_design] } {
            set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
            set input_net_signals [get_nets -of [get_pins -of $output_net_signals] -boundary_type upper]
            set input_signals [get_pins -of  $input_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]

            set sub_output_cell_t  [get_object_name $sub_output_cell]
            set sub_output_cell_i "$sub_output_cell_t/*"
            set sub_output_to_noc_pins [get_pins -of [get_nets -of [get_pins -of [get_nets -of $input_signals]] -boundary_type lower ] -filter "full_name =~ \"$sub_output_cell_i\"" ]
            set noc_check_pins [get_pins "$sub_output_cell_t/M* $sub_output_cell_t/PAD*" -filter "pin_direction =~ out"]
            set sub_output_to_top_pins [remove_from_collection [remove_from_collection [get_pins $sub_output_cell_i -filter "pin_direction =~ out"] $sub_output_to_noc_pins] $noc_check_pins]


            #set sub_output_cell_t [file dirname [get_object_name $sub_output_cell]]
            #set sub_output_cell_i "$sub_output_cell_t/*"
            #set sub_output_to_noc_pins [get_pins -of [get_nets -of $input_signals] -filter "full_name =~ \"$sub_output_cell_i\""]
            #set noc_check_pins [get_pins "$sub_output_cell_t/M* $sub_output_cell_t/PAD*" -filter "pin_direction =~ out"]
            #set sub_outop_to_top_pins [remove_from_collection [remove_from_collection [get_pins $sub_output_cell_i -filter "pin_direction =~ out"] $sub_output_to_noc_pins] $noc_check_pins]
          } elseif { [regexp {.*noc_left.*} $sub_empty_design] } {


            set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
            set input_net_signals [get_nets -of [get_pins -of $output_net_signals] -boundary_type lower]
            set input_signals [get_pins -of  $input_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]            
            
            
            set sub_output_cell_t  [get_object_name $sub_output_cell]
            set sub_output_cell_i "$sub_output_cell_t/*"

            set input_net_signals [get_nets -of  [get_pins -of [get_cells $sub_input_cell] -filter "pin_direction =~ in"]]
            set output_net_signals [get_nets -of [get_pins -of $input_net_signals] -boundary_type upper]
            set output_signals [get_pins -of  $output_net_signals  -filter "full_name =~ \"$sub_output_cell_i\""]


            set sub_input_to_noc_pins [get_pins -of [get_nets -of [get_pins -of [get_nets -of $output_signals]] -boundary_type lower ] -filter "full_name =~ \"$sub_input_cell_i\"" ]
            set noc_check_pins [get_pins "$sub_output_cell_t/M* $sub_output_cell_t/PAD*" -filter "pin_direction =~ in"]
            set sub_input_to_top_pins [remove_from_collection [remove_from_collection [get_pins $sub_input_cell_i -filter "pin_direction =~ in"] $sub_input_to_noc_pins] $noc_check_pins]

          } else {
            set output_net_signals [get_nets -of  [get_pins -of [get_cells $sub_output_cell] -filter "pin_direction =~ out"]]
            set input_signals [get_pins -of  $output_net_signals  -filter "full_name =~ \"$sub_input_cell_i\""]
          }





          
          
          set floating_signals_num 0
          echo "" > ../reports/${curr_design}_floating_signals_list.rpt
          # echo floating_signals_list
          foreach_in_collection check_pin $input_signals {
             set pin_name [get_attribute [get_pins $check_pin] full_name]
             set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
             if {$count == 1} {
                  incr floating_signals_num
                  set floating_signals [get_attribute [get_pins $pin_name] full_name]
                  echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
             }
          }
          
          # input signal number
          set input_signal_num [sizeof_collection  $input_signals ]
          echo "${curr_design} input signal (from $sub_empty_design) num (A): $input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt


          # floating signlas number
          echo "${curr_design} is floating signlas (from $sub_empty_design) num (B): $floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
          
          # should insert lp cell number
          set should_insert_lp_cell_num [expr $input_signal_num - $floating_signals_num]
          echo "${curr_design} should insert lp cells (from $sub_empty_design) num  (C=A-B): $should_insert_lp_cell_num\n"  >> ../reports/insert_lp_cell_num_check.rpt




          if { [regexp {.*inno_ddr.*} $sub_empty_design] } {
              # input signal number
              set sub_output_to_top_num [sizeof_collection  $sub_output_to_top_pins ]
              echo "$sub_empty_design output (to top) signals num (A): $sub_output_to_top_num" >> ../reports/insert_lp_cell_num_check.rpt

              set top_floating_signals_num 0
              # echo floating_signals_list
              foreach_in_collection check_pin $sub_output_to_top_pins {
                 set pin_name [get_attribute [get_pins $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
                 if {$count == 1} {
                      incr top_floating_signals_num
                      set floating_signals [get_attribute [get_pins $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
                 }
              }

              # floating signlas number
              echo "$sub_empty_design output (to top) is floating signlas  num (B): $top_floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
              
              # should insert lp cell number
              set top_should_insert_lp_cell_num [expr $sub_output_to_top_num - $top_floating_signals_num]
              echo "$sub_empty_design output (to top) should insert lp cells num  (C=A-B): $top_should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt

              incr floating_signals_num $top_floating_signals_num
              incr should_insert_lp_cell_num $top_should_insert_lp_cell_num


              # top is inserted  lp cell number
              set subtop_dir [file dirname [get_object_name $sub_output_cell]]
              set subtop_insert_lp_cell_num [sizeof_collection   [get_cells $subtop_dir/.* -regexp  -filter "ref_name =~ .*LVLU.* || ref_name =~ .*LVLD.* || ref_name =~ .*ISO.*" ]]
              echo "$subtop_dir is inserted lp cells num  : $subtop_insert_lp_cell_num\n"  >> ../reports/insert_lp_cell_num_check.rpt


          } elseif { [regexp {.*noc_left.*} $sub_empty_design] } {

              # input signal number
              set sub_input_to_top_num [sizeof_collection  $sub_input_to_top_pins ]
              echo "$sub_design input (from top) signals num (A): $sub_input_to_top_num" >> ../reports/insert_lp_cell_num_check.rpt

              set top_floating_signals_num 0
              # echo floating_signals_list
              foreach_in_collection check_pin $sub_input_to_top_pins {
                 set pin_name [get_attribute [get_pins $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
                 if {$count == 1} {
                      incr top_floating_signals_num
                      set floating_signals [get_attribute [get_pins $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
                 }
              }

              # floating signlas number
              echo "$sub_design input (from top) is floating signlas  num (B): $top_floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
              
              # should insert lp cell number
              set top_should_insert_lp_cell_num [expr $sub_input_to_top_num - $top_floating_signals_num]
              echo "$sub_design input (from top) should insert lp cells num  (C=A-B): $top_should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt

              incr floating_signals_num $top_floating_signals_num
              incr should_insert_lp_cell_num $top_should_insert_lp_cell_num




          }

          if { [regexp {.*noc_right.*} $sub_design] } {
            set scp_output_net_signals [get_nets -of  [get_pins -of [get_cells "u_up_top_wrap/scp_top_wrap_inst"] -filter "pin_direction =~ out"]]
            set right_input_net_signals [get_nets -of [get_pins -of $scp_output_net_signals] -boundary_type upper]
            set right_input_signals [get_pins -of  $right_input_net_signals  -filter "full_name =~ u_right_top/*"]



              set scp2right_floating_signals_num 0
              # echo floating_signals_list
              foreach_in_collection check_pin $right_input_signals {
                 set pin_name [get_attribute [get_pins $check_pin] full_name]
                 set count [sizeof_collection [all_fanout -flat -from [get_pins $pin_name]]]
                 if {$count == 1} {
                      incr scp2right_floating_signals_num
                      set floating_signals [get_attribute [get_pins $pin_name] full_name]
                      echo "$floating_signals" >> ../reports/${curr_design}_floating_signals_list.rpt
                 }
              }


            set scp2right_input_signal_num [sizeof_collection  $right_input_signals ]
            echo "right_top input signal (from scp ) num (A): $scp2right_input_signal_num" >> ../reports/insert_lp_cell_num_check.rpt

            # floating signlas number
            echo "right_top input signal (from scp ) is floating signlas  num (B): $scp2right_floating_signals_num" >> ../reports/insert_lp_cell_num_check.rpt
            
            # should insert lp cell number
            set scp2right_should_insert_lp_cell_num [expr $scp2right_input_signal_num - $scp2right_floating_signals_num]
            echo "right_top input signal (from scp ) should insert lp cells num  (C=A-B): $scp2right_should_insert_lp_cell_num"  >> ../reports/insert_lp_cell_num_check.rpt

            incr floating_signals_num $scp2right_floating_signals_num
            incr should_insert_lp_cell_num $scp2right_should_insert_lp_cell_num



          }


          
          incr floating_signals_sum $floating_signals_num
          incr should_insert_lp_cell_sum $should_insert_lp_cell_num
          incr subtop_insert_lp_cell_sum $subtop_insert_lp_cell_num
        }


      }


      #  inserted lp cell number
      current_design ${curr_design}
      set insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
      echo "${curr_design} is inserted lp cells num: $insert_lp_cell_num  \n\n\n\n" >> ../reports/insert_lp_cell_num_check.rpt
      current_design ${design_top}
      incr insert_lp_cell_sum $insert_lp_cell_num
  }
}


set all_sub_insert_lp_cell_sum [expr $insert_lp_cell_sum + $subtop_insert_lp_cell_sum]
 
echo "All sub_module is floating signlas sum : $floating_signals_sum"  >> ../reports/insert_lp_cell_num_check.rpt
echo "All sub_module should insert lp cells sum : $should_insert_lp_cell_sum"  >> ../reports/insert_lp_cell_num_check.rpt
echo "All sub_module is inserted lp cells sum : $all_sub_insert_lp_cell_sum\n"  >> ../reports/insert_lp_cell_num_check.rpt

set top_insert_lp_cell_num [sizeof_collection   [get_cells * -filter "ref_name =~ *LVLU* || ref_name =~ *LVLD* || ref_name =~ *ISO*" -hierarchical]]
echo "${compile_rtl_scope} is inserted all lp cells num: $top_insert_lp_cell_num\n\n" >> ../reports/insert_lp_cell_num_check.rpt


if {$should_insert_lp_cell_sum != $all_sub_insert_lp_cell_sum} {
  echo "Error: should_insert_lp_cell_sum is not equal to all_sub_insert_lp_cell_sum"
}
if {$top_insert_lp_cell_num != $all_sub_insert_lp_cell_sum} {
  echo "Error: top_insert_lp_cell_num is not equal to all_sub_insert_lp_cell_sum"
}

if {($should_insert_lp_cell_sum == $all_sub_insert_lp_cell_sum) && ($top_insert_lp_cell_num == $all_sub_insert_lp_cell_sum)} {
  echo "Information: Insert lp cells is success"
}
